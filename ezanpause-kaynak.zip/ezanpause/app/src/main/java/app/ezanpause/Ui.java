package app.ezanpause;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

/** Açık tema için ortak görünüm yardımcıları. */
final class Ui {
    static final int BG = Color.parseColor("#F1F7F4");
    static final int CARD = Color.WHITE;
    static final int LINE = Color.parseColor("#E2E8F0");
    static final int TEXT = Color.parseColor("#0F172A");
    static final int MUTED = Color.parseColor("#64748B");
    static final int GREEN = Color.parseColor("#14532D");
    static final int GREEN_MID = Color.parseColor("#16A34A");
    static final int MINT = Color.parseColor("#DCFCE7");
    static final int MINT_LINE = Color.parseColor("#86EFAC");
    static final int AMBER = Color.parseColor("#B45309");
    static final int AMBER_BG = Color.parseColor("#FEF3C7");
    static final int AMBER_LINE = Color.parseColor("#F59E0B");
    static final int WARN_RED = Color.parseColor("#B91C1C");

    private Ui() {}

    static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout.LayoutParams lp(Context c, int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    static LinearLayout.LayoutParams wrapLp(Context c, int l, int t, int r, int b) {
        return lp(c, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, l, t, r, b);
    }

    static LinearLayout.LayoutParams matchLp(Context c, int l, int t, int r, int b) {
        return lp(c, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, l, t, r, b);
    }

    static LinearLayout.LayoutParams weightLp(Context c, float w, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    static TextView text(Context c, String t, int sp, int color, boolean bold) {
        TextView tv = new TextView(c);
        tv.setText(I18n.t(t));
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    static GradientDrawable shape(Context c, int fill, int radiusDp, int stroke, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeDp > 0) g.setStroke(dp(c, strokeDp), stroke);
        return g;
    }

    static Drawable ripple(Context c, int fill, int radiusDp, int stroke, int strokeDp) {
        return new RippleDrawable(ColorStateList.valueOf(0x22000000),
                shape(c, fill, radiusDp, stroke, strokeDp), null);
    }

    static ImageView icon(Context c, String name, int color, int sizeDp) {
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(new Ic(name, color));
        iv.setLayoutParams(new LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp)));
        return iv;
    }

    /** Dairesel zemin üstünde simge (üst çubuk düğmeleri). */
    static FrameLayout circleIcon(Context c, String name, int iconColor, int bg, int stroke, int boxDp, int iconDp) {
        FrameLayout f = new FrameLayout(c);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(bg);
        if (stroke != 0) g.setStroke(dp(c, 1), stroke);
        f.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22000000), g, null));
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(new Ic(name, iconColor));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(dp(c, iconDp), dp(c, iconDp), Gravity.CENTER);
        f.addView(iv, p);
        f.setClickable(true);
        f.setFocusable(true);
        return f;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = column(c);
        l.setBackground(shape(c, CARD, 20, LINE, 1));
        l.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 16));
        return l;
    }

    /** Simge + yazılı tıklanabilir düğme. */
    static final class Btn extends LinearLayout {
        final TextView label;
        final ImageView icon;

        Btn(Context c, String iconName, String text, int fill, int textColor, int stroke, int heightDp) {
            super(c);
            setOrientation(HORIZONTAL);
            setGravity(Gravity.CENTER);
            setBackground(ripple(c, fill, 14, stroke, stroke == 0 ? 0 : 1));
            setClickable(true);
            setFocusable(true);
            setMinimumHeight(dp(c, heightDp));
            setPadding(dp(c, 12), dp(c, 8), dp(c, 12), dp(c, 8));
            if (iconName != null) {
                icon = Ui.icon(c, iconName, textColor, 18);
                addView(icon, lp(c, dp(c, 18), dp(c, 18), 0, 0, 8, 0));
            } else {
                icon = null;
            }
            label = Ui.text(c, text, 14, textColor, true);
            label.setGravity(Gravity.CENTER);
            addView(label, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
    }

    static void toast(Context c, CharSequence s, int len) {
        android.widget.Toast.makeText(c, I18n.t(s), len).show();
    }

    static Btn button(Context c, String iconName, String text, int fill, int textColor, int stroke) {
        return new Btn(c, iconName, text, fill, textColor, stroke, 46);
    }

    static EditText field(Context c, String hint, boolean number) {
        EditText et = new EditText(c);
        if (number) et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setHint(I18n.t(hint));
        et.setTextColor(TEXT);
        et.setHintTextColor(MUTED);
        et.setSingleLine(true);
        et.setTextSize(16);
        et.setBackground(shape(c, Color.parseColor("#F8FAFC"), 12, Color.parseColor("#CBD5E1"), 1));
        et.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        return et;
    }

    static void styleSwitch(Switch sw) {
        ColorStateList thumb = new ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{Color.WHITE, Color.parseColor("#F1F5F9")});
        ColorStateList track = new ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{GREEN, Color.parseColor("#CBD5E1")});
        sw.setThumbTintList(thumb);
        sw.setTrackTintList(track);
    }

    static Switch toggle(Context c, String label) {
        Switch sw = new Switch(c);
        sw.setText(I18n.t(label));
        sw.setTextColor(TEXT);
        sw.setTextSize(15);
        sw.setPadding(0, dp(c, 8), 0, dp(c, 8));
        styleSwitch(sw);
        return sw;
    }

    static CheckBox check(Context c, String label) {
        CheckBox cb = new CheckBox(c);
        cb.setText(I18n.t(label));
        cb.setTextColor(TEXT);
        cb.setTextSize(15);
        cb.setButtonTintList(new ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{GREEN, MUTED}));
        return cb;
    }

    /** İnce ilerleme çubuğu. */
    static final class Bar extends View {
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float fraction;

        Bar(Context c, int trackColor, int fillColor) {
            super(c);
            track.setColor(trackColor);
            fill.setColor(fillColor);
        }

        void setFraction(float f) {
            float nf = Math.max(0f, Math.min(1f, f));
            if (Math.abs(nf - fraction) > 0.001f) {
                fraction = nf;
                invalidate();
            }
        }

        @Override
        protected void onDraw(Canvas cv) {
            float h = getHeight();
            float w = getWidth();
            cv.drawRoundRect(new RectF(0, 0, w, h), h / 2, h / 2, track);
            float fw = Math.max(h, w * fraction);
            if (fraction > 0f) cv.drawRoundRect(new RectF(0, 0, fw, h), h / 2, h / 2, fill);
        }
    }

    static String humanSec(int sec) {
        if (sec < 60) return sec + " sn";
        int m = sec / 60;
        int r = sec % 60;
        return r == 0 ? m + " dk" : m + " dk " + r + " sn";
    }

    static String hms(long ms) {
        long sec = Math.max(0, ms / 1000);
        return String.format(java.util.Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60);
    }
}
