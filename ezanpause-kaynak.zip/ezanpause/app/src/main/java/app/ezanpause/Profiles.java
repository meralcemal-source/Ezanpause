package app.ezanpause;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Cihazda saklanan kullanıcı profilleri: her profil kendi şehir, süre ve vakit ayarlarını taşır. */
final class Profiles {
    static final String DEFAULT_NAME = "Varsayılan";
    private static final String PREFS = "ezanpause_profiles";

    static final class P {
        final String id;
        String name;
        Settings settings;

        P(String id, String name, Settings settings) {
            this.id = id;
            this.name = name;
            this.settings = settings;
        }
    }

    private Profiles() {}

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static List<P> list(Context c) {
        List<P> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs(c).getString("list", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.add(new P(o.getString("id"), o.getString("name"), Settings.fromJson(o.getJSONObject("data"))));
            }
        } catch (JSONException ignored) {
        }
        if (out.isEmpty()) {
            P p = new P("p" + System.currentTimeMillis(), DEFAULT_NAME, Settings.load(c));
            out.add(p);
            write(c, out, p.id);
        }
        return out;
    }

    static String activeId(Context c) {
        List<P> all = list(c);
        String id = prefs(c).getString("active", all.get(0).id);
        for (P p : all) if (p.id.equals(id)) return id;
        return all.get(0).id;
    }

    static P active(Context c) {
        String id = activeId(c);
        for (P p : list(c)) if (p.id.equals(id)) return p;
        return list(c).get(0);
    }

    private static void write(Context c, List<P> all, String activeId) {
        JSONArray arr = new JSONArray();
        try {
            for (P p : all) {
                JSONObject o = new JSONObject();
                o.put("id", p.id);
                o.put("name", p.name);
                o.put("data", p.settings.toJson());
                arr.put(o);
            }
        } catch (JSONException ignored) {
        }
        prefs(c).edit().putString("list", arr.toString()).putString("active", activeId).apply();
    }

    /** Geçerli ayarları etkin profilin içine yazar (Kaydet'ten sonra çağrılır). */
    static void syncActive(Context c) {
        List<P> all = list(c);
        String id = activeId(c);
        Settings now = Settings.load(c);
        for (P p : all) if (p.id.equals(id)) p.settings = now;
        write(c, all, id);
    }

    /** Geçerli ayarlardan yeni profil oluşturur ve etkin yapar. */
    static void create(Context c, String name) {
        syncActive(c);
        List<P> all = list(c);
        P p = new P("p" + System.currentTimeMillis(), clean(name), Settings.load(c));
        all.add(p);
        write(c, all, p.id);
    }

    static void activate(Context c, String id) {
        syncActive(c);
        List<P> all = list(c);
        for (P p : all) {
            if (p.id.equals(id)) {
                p.settings.save(c);
                write(c, all, id);
                Scheduler.tick(c);
                return;
            }
        }
    }

    static void rename(Context c, String id, String name) {
        List<P> all = list(c);
        for (P p : all) if (p.id.equals(id)) p.name = clean(name);
        write(c, all, activeId(c));
    }

    /** En az bir profil kalır. Etkin profil silinirse ilki etkinleşir. */
    static boolean delete(Context c, String id) {
        List<P> all = list(c);
        if (all.size() <= 1) return false;
        String active = activeId(c);
        P target = null;
        for (P p : all) if (p.id.equals(id)) target = p;
        if (target == null) return false;
        all.remove(target);
        if (active.equals(id)) {
            P first = all.get(0);
            first.settings.save(c);
            active = first.id;
        }
        write(c, all, active);
        Scheduler.tick(c);
        return true;
    }

    private static String clean(String n) {
        String t = n == null ? "" : n.trim();
        if (t.isEmpty()) t = "Profil";
        return t.length() > 24 ? t.substring(0, 24) : t;
    }
}
