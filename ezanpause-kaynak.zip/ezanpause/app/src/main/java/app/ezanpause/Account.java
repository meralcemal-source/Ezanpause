package app.ezanpause;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings.Secure;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Hesap (e-posta + şifre), cihaz sınırı ve Pro durumu. Firebase'e doğrudan REST ile bağlanır (ek kütüphane yok).
 * Kurallar: ücretsiz hesap 1 cihaz, Pro hesap 5 cihaz. Pro durumu Firestore'daki users/{uid} belgesindedir
 * ve yalnızca sahibi (Firebase konsolu) tarafından değiştirilebilir.
 */
final class Account {
    static final String API_KEY = "AIzaSyDcxhLPviZtmS9PGWxMn5urcr110hESCPM";
    static final String PROJECT = "ezanpause";
    static final int FREE_DEVICES = 1;
    static final int PRO_DEVICES = 5;
    private static final String PREFS = "ezanpause_account";
    /** Çevrimdışıyken Pro'nun en fazla kaç gün daha geçerli sayılacağı (son doğrulamadan sonra). */
    private static final long GRACE_MS = 14L * 24 * 3600_000L;

    interface Callback {
        void done(boolean ok, String message);
    }

    static final class Device {
        final String id, model;
        final long seen;

        Device(String raw) {
            String[] p = raw.split("\\|", 3);
            id = p[0];
            model = p.length > 1 ? p[1] : "?";
            long s = 0;
            try {
                s = p.length > 2 ? Long.parseLong(p[2]) : 0;
            } catch (NumberFormatException ignored) {
            }
            seen = s;
        }

        String raw() {
            return id + "|" + model + "|" + seen;
        }
    }

    private Account() {
    }

    // ------------------------------------------------------------------ durum

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean signedIn(Context c) {
        return p(c).getString("refresh", null) != null && p(c).getString("uid", null) != null;
    }

    static String email(Context c) {
        return p(c).getString("email", "");
    }

    static String deviceId(Context c) {
        String id = Secure.getString(c.getContentResolver(), Secure.ANDROID_ID);
        return id == null ? "unknown" : id;
    }

    static String deviceModel() {
        String m = (Build.MANUFACTURER + " " + Build.MODEL).replace("|", " ").trim();
        return m.isEmpty() ? "Android" : m;
    }

    /** Hesap Pro mu? (son bilinen duruma bakar; internet gerekmez). */
    static boolean isPro(Context c) {
        SharedPreferences s = p(c);
        if (!signedIn(c)) return false;
        if (!"pro".equals(s.getString("plan", "free"))) return false;
        long now = System.currentTimeMillis();
        long until = s.getLong("until", 0);
        if (until != 0 && until < now) return false;
        return now - s.getLong("verified", 0) < GRACE_MS;
    }

    static int deviceLimit(Context c) {
        return "pro".equals(p(c).getString("plan", "free")) ? PRO_DEVICES : FREE_DEVICES;
    }

    static String planText(Context c) {
        if (!signedIn(c)) return "Giriş yapılmadı";
        if (isPro(c)) {
            long until = p(c).getLong("until", 0);
            if (until == 0) return "Pro (sınırsız)";
            return "Pro · " + new java.text.SimpleDateFormat("d.MM.yyyy", java.util.Locale.US).format(new java.util.Date(until)) + " tarihine kadar";
        }
        return "Ücretsiz";
    }

    static void signOutLocal(Context c) {
        p(c).edit().clear().apply();
        try {
            Scheduler.tick(c);
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ giriş / kayıt

    static void signUp(final Context c, final String email, final String pw, final Callback cb) {
        auth(c, "accounts:signUp", email, pw, cb);
    }

    static void signIn(final Context c, final String email, final String pw, final Callback cb) {
        auth(c, "accounts:signInWithPassword", email, pw, cb);
    }

    private static void auth(final Context c, final String endpoint, final String email, final String pw, final Callback cb) {
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject().put("email", email).put("password", pw).put("returnSecureToken", true);
                Resp r = http("POST", "https://identitytoolkit.googleapis.com/v1/" + endpoint + "?key=" + API_KEY, null, body.toString(), false);
                if (r.code != 200) {
                    cb.done(false, errorText(r.body));
                    return;
                }
                JSONObject o = new JSONObject(r.body);
                p(c).edit().clear()
                        .putString("uid", o.getString("localId"))
                        .putString("email", email)
                        .putString("refresh", o.getString("refreshToken"))
                        .putString("token", o.getString("idToken"))
                        .putLong("exp", System.currentTimeMillis() + Long.parseLong(o.optString("expiresIn", "3600")) * 1000L)
                        .apply();
                // Hesap bilgisini ve cihaz kaydını kur
                String msg = syncBlocking(c, true);
                if (msg == null) cb.done(true, "");
                else if ("LIMIT".equals(msg)) cb.done(true, "LIMIT");
                else cb.done(false, msg);
            } catch (Throwable t) {
                cb.done(false, "Bağlantı kurulamadı. İnternetinizi kontrol edin.");
            }
        }).start();
    }

    static void resetPassword(final String email, final Callback cb) {
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject().put("requestType", "PASSWORD_RESET").put("email", email);
                Resp r = http("POST", "https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=" + API_KEY, null, body.toString(), false);
                if (r.code == 200) cb.done(true, "Şifre sıfırlama bağlantısı e-posta adresinize gönderildi.");
                else cb.done(false, errorText(r.body));
            } catch (Throwable t) {
                cb.done(false, "Bağlantı kurulamadı. İnternetinizi kontrol edin.");
            }
        }).start();
    }

    // ------------------------------------------------------------------ senkron (plan + cihazlar)

    /** Arka planda hesabı yeniler. cb.message: null/"" tamam, "LIMIT" cihaz sınırı dolu, "KICKED" bu cihaz çıkarıldı. */
    static void refresh(final Context c, final Callback cb) {
        if (!signedIn(c)) return;
        new Thread(() -> {
            try {
                String msg = syncBlocking(c, false);
                if (cb != null) cb.done(msg == null, msg == null ? "" : msg);
            } catch (Throwable t) {
                if (cb != null) cb.done(false, "Bağlantı kurulamadı. İnternetinizi kontrol edin.");
            }
        }).start();
    }

    /**
     * Firestore belgesini okur/oluşturur, planı önbelleğe alır, bu cihazı kaydeder.
     * register=true ise bu cihaz listede yoksa eklenmeye çalışılır (yer yoksa "LIMIT").
     * register=false ise cihaz listede yoksa "KICKED" döner ve oturum kapatılır.
     */
    private static String syncBlocking(Context c, boolean register) throws Exception {
        String token = token(c);
        if (token == null) return "Oturum süresi doldu, yeniden giriş yapın.";
        String uid = p(c).getString("uid", "");
        String url = docUrl(uid);
        Resp r = http("GET", url, token, null, false);
        List<Device> devices = new ArrayList<>();
        String plan = "free";
        long until = 0;
        boolean exists = r.code == 200;
        if (exists) {
            JSONObject f = new JSONObject(r.body).optJSONObject("fields");
            if (f != null) {
                plan = str(f, "plan", "free");
                until = Long.parseLong(str(f, "until", "0"));
                JSONObject arr = f.optJSONObject("devices");
                if (arr != null && arr.optJSONObject("arrayValue") != null) {
                    JSONArray vs = arr.getJSONObject("arrayValue").optJSONArray("values");
                    if (vs != null) for (int i = 0; i < vs.length(); i++) devices.add(new Device(vs.getJSONObject(i).getString("stringValue")));
                }
            }
        } else if (r.code != 404) {
            return errorText(r.body);
        }
        int limit = "pro".equals(plan) ? PRO_DEVICES : FREE_DEVICES;
        String me = deviceId(c);
        boolean found = false;
        for (Device d : devices) if (d.id.equals(me)) found = true;

        p(c).edit().putString("plan", plan).putLong("until", until).putLong("verified", System.currentTimeMillis())
                .putInt("devCount", devices.size()).apply();

        if (!found) {
            if (!register) {
                signOutLocal(c);
                return "KICKED";
            }
            if (devices.size() >= limit) return "LIMIT";
            devices.add(new Device(me + "|" + deviceModel() + "|" + System.currentTimeMillis()));
            writeDevices(c, token, uid, devices, !exists);
        } else if (register || true) {
            // son görülme zamanını en fazla günde bir güncelle
            long last = p(c).getLong("seen_written", 0);
            if (System.currentTimeMillis() - last > 24L * 3600_000L) {
                List<Device> upd = new ArrayList<>();
                for (Device d : devices) upd.add(d.id.equals(me) ? new Device(me + "|" + deviceModel() + "|" + System.currentTimeMillis()) : d);
                writeDevices(c, token, uid, upd, false);
                p(c).edit().putLong("seen_written", System.currentTimeMillis()).apply();
            }
        }
        try {
            Scheduler.tick(c);
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** Hesaptaki cihazları getirir (cihaz yönetimi ekranı için). */
    static List<Device> fetchDevices(Context c) throws Exception {
        String token = token(c);
        Resp r = http("GET", docUrl(p(c).getString("uid", "")), token, null, false);
        List<Device> out = new ArrayList<>();
        if (r.code != 200) return out;
        JSONObject f = new JSONObject(r.body).optJSONObject("fields");
        if (f == null) return out;
        JSONObject arr = f.optJSONObject("devices");
        if (arr != null && arr.optJSONObject("arrayValue") != null) {
            JSONArray vs = arr.getJSONObject("arrayValue").optJSONArray("values");
            if (vs != null) for (int i = 0; i < vs.length(); i++) out.add(new Device(vs.getJSONObject(i).getString("stringValue")));
        }
        return out;
    }

    /** Verilen cihazı hesaptan çıkarır; "me" ise bu cihaz yeniden kaydedilir (limit dolu cihaz değiştirme). */
    static void removeDevice(final Context c, final String deviceId, final boolean registerMe, final Callback cb) {
        new Thread(() -> {
            try {
                String token = token(c);
                String uid = p(c).getString("uid", "");
                List<Device> list = fetchDevices(c);
                List<Device> out = new ArrayList<>();
                for (Device d : list) if (!d.id.equals(deviceId)) out.add(d);
                String me = deviceId(c);
                if (registerMe) {
                    boolean has = false;
                    for (Device d : out) if (d.id.equals(me)) has = true;
                    if (!has) out.add(new Device(me + "|" + deviceModel() + "|" + System.currentTimeMillis()));
                }
                writeDevices(c, token, uid, out, false);
                if (deviceId.equals(me) && !registerMe) signOutLocal(c);
                else syncBlocking(c, false);
                cb.done(true, "");
            } catch (Throwable t) {
                cb.done(false, "İşlem yapılamadı. İnternetinizi kontrol edin.");
            }
        }).start();
    }

    private static void writeDevices(Context c, String token, String uid, List<Device> devices, boolean create) throws Exception {
        JSONArray vals = new JSONArray();
        for (Device d : devices) vals.put(new JSONObject().put("stringValue", d.raw()));
        JSONObject fields = new JSONObject().put("devices", new JSONObject().put("arrayValue", new JSONObject().put("values", vals)));
        StringBuilder mask = new StringBuilder("?updateMask.fieldPaths=devices");
        if (create) {
            fields.put("plan", new JSONObject().put("stringValue", "free"));
            fields.put("until", new JSONObject().put("integerValue", "0"));
            fields.put("email", new JSONObject().put("stringValue", p(c).getString("email", "")));
            mask.append("&updateMask.fieldPaths=plan&updateMask.fieldPaths=until&updateMask.fieldPaths=email");
        }
        Resp r = http("PATCH", docUrl(uid) + mask, token, new JSONObject().put("fields", fields).toString(), true);
        if (r.code != 200) throw new Exception("write " + r.code + " " + r.body);
    }

    // ------------------------------------------------------------------ yardımcılar

    private static String docUrl(String uid) {
        return "https://firestore.googleapis.com/v1/projects/" + PROJECT + "/databases/(default)/documents/users/" + uid;
    }

    private static String str(JSONObject fields, String key, String def) {
        JSONObject o = fields.optJSONObject(key);
        if (o == null) return def;
        if (o.has("stringValue")) return o.optString("stringValue", def);
        if (o.has("integerValue")) return o.optString("integerValue", def);
        return def;
    }

    /** Geçerli bir erişim jetonu döndürür; süresi dolmuşsa yeniler. */
    private static String token(Context c) throws Exception {
        SharedPreferences s = p(c);
        String t = s.getString("token", null);
        if (t != null && s.getLong("exp", 0) > System.currentTimeMillis() + 60_000L) return t;
        String refresh = s.getString("refresh", null);
        if (refresh == null) return null;
        Resp r = http("POST", "https://securetoken.googleapis.com/v1/token?key=" + API_KEY, null,
                "grant_type=refresh_token&refresh_token=" + java.net.URLEncoder.encode(refresh, "UTF-8"), false, "application/x-www-form-urlencoded");
        if (r.code != 200) {
            if (r.code == 400 || r.code == 401) signOutLocal(c); // hesap silinmiş/şifre değişmiş
            return null;
        }
        JSONObject o = new JSONObject(r.body);
        s.edit().putString("token", o.getString("id_token"))
                .putString("refresh", o.optString("refresh_token", refresh))
                .putLong("exp", System.currentTimeMillis() + Long.parseLong(o.optString("expires_in", "3600")) * 1000L)
                .apply();
        return o.getString("id_token");
    }

    static String errorText(String body) {
        String m = "";
        try {
            m = new JSONObject(body).getJSONObject("error").optString("message", "");
        } catch (Throwable ignored) {
        }
        if (m.startsWith("EMAIL_EXISTS")) return "Bu e-posta ile zaten bir hesap var. Giriş yapın.";
        if (m.startsWith("INVALID_LOGIN_CREDENTIALS") || m.startsWith("INVALID_PASSWORD") || m.startsWith("EMAIL_NOT_FOUND"))
            return "E-posta veya şifre hatalı.";
        if (m.startsWith("WEAK_PASSWORD")) return "Şifre en az 6 karakter olmalı.";
        if (m.startsWith("INVALID_EMAIL")) return "E-posta adresi geçersiz.";
        if (m.startsWith("TOO_MANY_ATTEMPTS")) return "Çok fazla deneme yapıldı. Biraz bekleyip tekrar deneyin.";
        if (m.startsWith("OPERATION_NOT_ALLOWED")) return "E-posta ile giriş henüz açık değil (Firebase ayarı).";
        if (m.startsWith("USER_DISABLED")) return "Bu hesap devre dışı bırakılmış.";
        if (body != null && body.contains("PERMISSION_DENIED")) return "İzin hatası (Firestore kuralları). Kuralları yayınladığınızdan emin olun.";
        return "İşlem yapılamadı. " + (m.isEmpty() ? "" : "(" + m + ")");
    }

    private static final class Resp {
        int code;
        String body;
    }

    private static Resp http(String method, String url, String bearer, String body, boolean json) throws Exception {
        return http(method, url, bearer, body, json, "application/json");
    }

    private static Resp http(String method, String url, String bearer, String body, boolean ignored, String type) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(15000);
        con.setReadTimeout(20000);
        boolean patch = "PATCH".equals(method);
        con.setRequestMethod(patch ? "POST" : method); // Android PATCH'i desteklemez
        if (patch) con.setRequestProperty("X-HTTP-Method-Override", "PATCH");
        if (bearer != null) con.setRequestProperty("Authorization", "Bearer " + bearer);
        if (body != null) {
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", type);
            try (OutputStream os = con.getOutputStream()) {
                os.write(body.getBytes(StandardCharsets.UTF_8));
            }
        }
        Resp r = new Resp();
        r.code = con.getResponseCode();
        InputStream is = r.code >= 400 ? con.getErrorStream() : con.getInputStream();
        StringBuilder sb = new StringBuilder();
        if (is != null) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append('\n');
            }
        }
        r.body = sb.toString();
        con.disconnect();
        return r;
    }
}
