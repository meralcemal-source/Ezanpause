package app.ezanpause;

import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.PowerManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** Ayarlar: Pro gereksinimleri, kullanıcı profilleri, namaz ayarları, izinler ve deneme. */
public class SettingsActivity extends BaseActivity {
    private Settings s;

    private TextView tvProCount;
    private Ui.Bar proBar;
    private LinearLayout proList;
    private LinearLayout profileList;
    private TextView tvCity;
    private TextView tvGps;
    private TextView tvDurationHint;
    private EditText etDuration;
    private EditText etOffset;
    private Switch swEnabled;
    private Switch swRestore;
    private Switch swResume;
    private CheckBox cbImsak;
    private CheckBox cbOgle;
    private CheckBox cbIkindi;
    private CheckBox cbAksam;
    private CheckBox cbYatsi;
    private CheckBox cbSela;
    private CheckBox cbCumaSela;
    private android.widget.EditText etCumaMin;
    private android.widget.EditText etSelaMin;
    private TextView tvExact;
    private TextView tvNotif;
    private TextView tvBattery;
    private boolean bindingForm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        s = Settings.load(this);
        LinearLayout root = screen();
        topBar(root, "Ayarlar");
        Ui.Btn bLang = Ui.button(this, null, "Dil / Language: " + (I18n.isEnglish() ? "English" : "Türkçe"), Ui.CARD, Ui.TEXT, Ui.LINE);
        bLang.setOnClickListener(v -> showLanguageDialog(true));
        root.addView(bLang, Ui.matchLp(this, 0, 4, 0, 4));
        buildPro(root);
        buildProfiles(root);
        buildPrayerSettings(root);
        buildPermissions(root);
        bindForm();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshAll();
    }

    private void refreshAll() {
        refreshPro();
        refreshProfiles();
        refreshPermissions();
    }

    // ------------------------------------------------------------------ Pro için yapılması gerekenler

    private void buildPro(LinearLayout root) {
        LinearLayout box = Ui.column(this);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor("#FEF3C7"), Color.WHITE});
        bg.setCornerRadius(Ui.dp(this, 22));
        bg.setStroke(Ui.dp(this, 1), Color.parseColor("#FCD34D"));
        box.setBackground(bg);
        box.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14));

        LinearLayout head = Ui.row(this);
        FrameLayout star = Ui.circleIcon(this, "star", Ui.AMBER_LINE, Color.WHITE, 0, 40, 24);
        star.setClickable(false);
        head.addView(star, Ui.lp(this, Ui.dp(this, 40), Ui.dp(this, 40), 0, 0, 10, 0));
        LinearLayout t = Ui.column(this);
        t.addView(Ui.text(this, "Pro için yapılması gerekenler", 16, Ui.TEXT, true));
        tvProCount = Ui.text(this, "", 12, Ui.AMBER, true);
        t.addView(tvProCount);
        head.addView(t, Ui.weightLp(this, 1f, 0, 0, 0, 0));
        box.addView(head);

        proBar = new Ui.Bar(this, Color.parseColor("#FDE68A"), Ui.AMBER_LINE);
        box.addView(proBar, Ui.lp(this, ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 7), 0, 12, 0, 6));

        proList = Ui.column(this);
        box.addView(proList);

        Ui.Btn open = Ui.button(this, "star", "Pro ekranını aç", Ui.AMBER_BG, Ui.AMBER, 0);
        open.setOnClickListener(v -> startActivity(new Intent(this, ProActivity.class)));
        box.addView(open, Ui.matchLp(this, 0, 8, 0, 0));
        root.addView(box, Ui.matchLp(this, 0, 8, 0, 0));
    }

    private void refreshPro() {
        List<ProItems.Item> items = ProItems.items(this);
        int done = ProItems.doneCount(items);
        tvProCount.setText(I18n.t(done + " / " + items.size() + " tamamlandı"));
        proBar.setFraction(done / (float) items.size());
        proList.removeAllViews();
        for (final ProItems.Item it : items) {
            LinearLayout row = Ui.row(this);
            row.setPadding(0, Ui.dp(this, 7), 0, Ui.dp(this, 7));
            FrameLayout mark = it.done
                    ? Ui.circleIcon(this, "check", Color.WHITE, Ui.GREEN_MID, 0, 22, 13)
                    : Ui.circleIcon(this, "circle", Color.parseColor("#94A3B8"), Color.TRANSPARENT, 0, 22, 20);
            mark.setClickable(false);
            row.addView(mark, Ui.lp(this, Ui.dp(this, 22), Ui.dp(this, 22), 0, 0, 10, 0));
            TextView title = Ui.text(this, it.title, 13, it.done ? Ui.MUTED : Ui.TEXT, !it.done);
            row.addView(title, Ui.weightLp(this, 1f, 0, 0, 0, 0));
            if (!it.done) {
                row.addView(Ui.icon(this, "chevron_right", Ui.MUTED, 16),
                        Ui.lp(this, Ui.dp(this, 16), Ui.dp(this, 16), 0, 0, 0, 0));
                row.setClickable(true);
                row.setOnClickListener(v -> runProAction(it.action, () -> {
                    s = Settings.load(this);
                    bindForm();
                    refreshAll();
                }));
            }
            proList.addView(row);
        }
    }

    // ------------------------------------------------------------------ kullanıcı profilleri

    private void buildProfiles(LinearLayout root) {
        LinearLayout card = Ui.card(this);
        LinearLayout head = Ui.row(this);
        head.addView(Ui.icon(this, "person", Ui.GREEN, 20), Ui.lp(this, Ui.dp(this, 20), Ui.dp(this, 20), 0, 0, 8, 0));
        head.addView(Ui.text(this, "Kullanıcı profilleri", 16, Ui.TEXT, true));
        card.addView(head);
        card.addView(Ui.text(this, "Her profilin kendi şehri, sessizlik süresi ve vakit seçimi vardır. "
                + "Örneğin Ev, İş, Cami.", 12, Ui.MUTED, false), Ui.matchLp(this, 0, 4, 0, 6));

        profileList = Ui.column(this);
        card.addView(profileList);

        LinearLayout btns = Ui.row(this);
        Ui.Btn add = Ui.button(this, "plus", "Yeni profil", Ui.GREEN, Color.WHITE, 0);
        add.setOnClickListener(v -> askName("Yeni profil", "", name -> {
            Profiles.create(this, name);
            refreshAll();
        }));
        Ui.Btn ren = Ui.button(this, null, "Adını değiştir", Ui.CARD, Ui.TEXT, Color.parseColor("#CBD5E1"));
        ren.setOnClickListener(v -> {
            final Profiles.P a = Profiles.active(this);
            askName("Profil adı", a.name, name -> {
                Profiles.rename(this, a.id, name);
                refreshAll();
            });
        });
        Ui.Btn del = Ui.button(this, null, "Sil", Ui.CARD, Ui.WARN_RED, Color.parseColor("#FECACA"));
        del.setOnClickListener(v -> {
            final Profiles.P a = Profiles.active(this);
            new AlertDialog.Builder(this)
                    .setTitle(I18n.t("\"" + a.name + "\" silinsin mi?"))
                    .setPositiveButton(I18n.t("Sil"), (d, w) -> {
                        if (!Profiles.delete(this, a.id)) {
                            Ui.toast(this, "En az bir profil kalmalı", Toast.LENGTH_SHORT);
                        }
                        s = Settings.load(this);
                        bindForm();
                        refreshAll();
                    })
                    .setNegativeButton(I18n.t("Vazgeç"), null)
                    .show();
        });
        btns.addView(add, Ui.weightLp(this, 1.1f, 0, 0, 4, 0));
        btns.addView(ren, Ui.weightLp(this, 1.3f, 4, 0, 4, 0));
        btns.addView(del, Ui.weightLp(this, 0.7f, 4, 0, 0, 0));
        card.addView(btns, Ui.matchLp(this, 0, 10, 0, 0));
        root.addView(card, Ui.matchLp(this, 0, 14, 0, 0));
    }

    private interface NameCb {
        void ok(String name);
    }

    private void askName(String title, String initial, final NameCb cb) {
        final EditText et = Ui.field(this, "Profil adı", false);
        et.setText(initial);
        et.setSelection(initial.length());
        FrameLayout wrap = new FrameLayout(this);
        wrap.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0);
        wrap.addView(et);
        new AlertDialog.Builder(this)
                .setTitle(I18n.t(title))
                .setView(wrap)
                .setPositiveButton(I18n.t("Tamam"), (d, w) -> cb.ok(et.getText().toString()))
                .setNegativeButton(I18n.t("Vazgeç"), null)
                .show();
    }

    private void refreshProfiles() {
        profileList.removeAllViews();
        String activeId = Profiles.activeId(this);
        for (final Profiles.P p : Profiles.list(this)) {
            boolean active = p.id.equals(activeId);
            LinearLayout row = Ui.row(this);
            row.setPadding(Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10));
            row.setBackground(Ui.ripple(this, active ? Color.parseColor("#ECFDF5") : Color.parseColor("#F8FAFC"), 14,
                    active ? Ui.GREEN : Ui.LINE, active ? 2 : 1));
            row.setClickable(true);
            FrameLayout av = Ui.circleIcon(this, "person", active ? Color.WHITE : Ui.MUTED,
                    active ? Ui.GREEN : Color.parseColor("#E2E8F0"), 0, 38, 20);
            av.setClickable(false);
            row.addView(av, Ui.lp(this, Ui.dp(this, 38), Ui.dp(this, 38), 0, 0, 10, 0));
            LinearLayout col = Ui.column(this);
            col.addView(Ui.text(this, p.name, 15, Ui.TEXT, true));
            Settings ps = p.settings;
            col.addView(Ui.text(this, ps.city + " · " + Ui.humanSec(ps.durationSec) + " · " + ps.prayerCount() + " vakit",
                    11, Ui.MUTED, false));
            row.addView(col, Ui.weightLp(this, 1f, 0, 0, 8, 0));
            if (active) {
                TextView badge = Ui.text(this, "AKTİF", 10, Color.WHITE, true);
                badge.setBackground(Ui.shape(this, Ui.GREEN, 10, 0, 0));
                badge.setPadding(Ui.dp(this, 8), Ui.dp(this, 3), Ui.dp(this, 8), Ui.dp(this, 3));
                row.addView(badge);
            } else {
                row.addView(Ui.text(this, "Seç", 13, Ui.GREEN, true));
                row.setOnClickListener(v -> {
                    Profiles.activate(this, p.id);
                    s = Settings.load(this);
                    bindForm();
                    refreshAll();
                    Ui.toast(this, "\"" + p.name + "\" etkin", Toast.LENGTH_SHORT);
                });
            }
            profileList.addView(row, Ui.matchLp(this, 0, 4, 0, 4));
        }
    }

    // ------------------------------------------------------------------ namaz ayarları

    private void buildPrayerSettings(LinearLayout root) {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, "Namaz ayarları", 16, Ui.TEXT, true));

        swEnabled = Ui.toggle(this, "Ezan vaktinde otomatik sessize al");
        card.addView(swEnabled, Ui.matchLp(this, 0, 6, 0, 0));

        card.addView(label("Şehir"));
        LinearLayout cityRow = Ui.row(this);
        cityRow.setBackground(Ui.shape(this, Color.parseColor("#F8FAFC"), 12, Color.parseColor("#CBD5E1"), 1));
        cityRow.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));
        cityRow.setClickable(true);
        tvCity = Ui.text(this, "", 16, Ui.TEXT, false);
        cityRow.addView(tvCity, Ui.weightLp(this, 1f, 0, 0, 0, 0));
        cityRow.addView(Ui.text(this, "▾", 14, Ui.MUTED, false));
        cityRow.setOnClickListener(v -> showCityDialog(this::afterCityChange, this::gpsStatus));
        card.addView(cityRow);

        Ui.Btn gps = Ui.button(this, "pin", "Konumdan bul (GPS)", Ui.MINT, Ui.GREEN, 0);
        gps.setOnClickListener(v -> findCityByGps(this::gpsStatus, this::afterCityChange));
        card.addView(gps, Ui.matchLp(this, 0, 8, 0, 0));
        tvGps = Ui.text(this, "", 12, Ui.MUTED, false);
        card.addView(tvGps, Ui.matchLp(this, 2, 4, 0, 0));

        card.addView(label("Sessizlik süresi (saniye)"));
        etDuration = Ui.field(this, "örn. 240", true);
        card.addView(etDuration);
        tvDurationHint = Ui.text(this, "", 12, Ui.MUTED, false);
        card.addView(tvDurationHint, Ui.matchLp(this, 2, 4, 0, 0));
        etDuration.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence a, int b, int c, int d) {
            }

            @Override
            public void onTextChanged(CharSequence a, int b, int c, int d) {
            }

            @Override
            public void afterTextChanged(Editable e) {
                int v = parseInt(e.toString(), -1);
                tvDurationHint.setText(I18n.t(v < 1 ? "" : "= " + Ui.humanSec(v)));
            }
        });

        card.addView(label("Ezandan kaç saniye ÖNCE başlasın (0 = tam vaktinde)"));
        etOffset = Ui.field(this, "örn. 0", true);
        card.addView(etOffset);

        swRestore = Ui.toggle(this, "Bitince sesi geri aç");
        swResume = Ui.toggle(this, "Çalan müziği duraklat, bitince devam ettir");
        card.addView(swRestore, Ui.matchLp(this, 0, 10, 0, 0));
        card.addView(swResume);

        card.addView(label("Hangi vakitlerde"));
        cbImsak = Ui.check(this, "İmsak / Sabah");
        cbOgle = Ui.check(this, "Öğle");
        cbIkindi = Ui.check(this, "İkindi");
        cbAksam = Ui.check(this, "Akşam");
        cbYatsi = Ui.check(this, "Yatsı");
        cbSela = Ui.check(this, "Perşembe akşamı selâsı (yatsı ezanından önce) – bazı yörelerde gelenek");
        cbCumaSela = Ui.check(this, "Cuma selâsı (Cuma günü, öğle ezanından önce)");
        for (CheckBox cb : new CheckBox[]{cbImsak, cbOgle, cbIkindi, cbAksam, cbYatsi, cbCumaSela, cbSela}) card.addView(cb);
        card.addView(label("Cuma selâsı öğle ezanından kaç dakika önce okunuyor? (çoğu yerde 30–60)"));
        etCumaMin = Ui.field(this, "45", true);
        card.addView(etCumaMin);
        card.addView(label("Perşembe selâsı yatsı ezanından kaç dakika önce okunuyor? (çoğu yerde 15–30)"));
        etSelaMin = Ui.field(this, "20", true);
        card.addView(etSelaMin);

        Ui.Btn save = Ui.button(this, "check", "Kaydet", Ui.GREEN, Color.WHITE, 0);
        save.setOnClickListener(v -> save());
        card.addView(save, Ui.matchLp(this, 0, 16, 0, 0));
        root.addView(card, Ui.matchLp(this, 0, 14, 0, 0));
    }

    private void gpsStatus(String text, boolean found) {
        tvGps.setText(I18n.t(text));
        tvGps.setTextColor(found ? Ui.GREEN : Ui.MUTED);
    }

    private void afterCityChange() {
        s = Settings.load(this);
        bindForm();
        refreshAll();
    }

    private TextView label(String t) {
        TextView tv = Ui.text(this, t, 12, Ui.MUTED, true);
        tv.setPadding(Ui.dp(this, 2), Ui.dp(this, 14), 0, Ui.dp(this, 4));
        return tv;
    }

    private void bindForm() {
        bindingForm = true;
        swEnabled.setChecked(s.enabled);
        tvCity.setText(I18n.t(s.city));
        etDuration.setText(String.valueOf(s.durationSec));
        etOffset.setText(String.valueOf(s.offsetSec));
        swRestore.setChecked(s.restore);
        swResume.setChecked(s.resume);
        cbImsak.setChecked(s.imsak);
        cbOgle.setChecked(s.ogle);
        cbIkindi.setChecked(s.ikindi);
        cbAksam.setChecked(s.aksam);
        cbYatsi.setChecked(s.yatsi);
        cbSela.setChecked(s.sela);
        cbCumaSela.setChecked(s.cumaSela);
        etCumaMin.setText(String.valueOf(s.cumaSelaMin));
        etSelaMin.setText(String.valueOf(s.selaMin));
        bindingForm = false;
    }

    private void save() {
        int dur = parseInt(etDuration.getText().toString(), -1);
        int off = parseInt(etOffset.getText().toString(), 0);
        if (dur < 1 || dur > Settings.MAX_DURATION_SEC) {
            Ui.toast(this, "Süre 1 ile " + Settings.MAX_DURATION_SEC + " saniye arasında olmalı", Toast.LENGTH_LONG);
            return;
        }
        if (off < 0 || off > Settings.MAX_OFFSET_SEC) {
            Ui.toast(this, "Öncesi 0 ile " + Settings.MAX_OFFSET_SEC + " saniye arasında olmalı", Toast.LENGTH_LONG);
            return;
        }
        s = Settings.load(this); // şehir ayrıca değişmiş olabilir
        s.enabled = swEnabled.isChecked();
        s.durationSec = dur;
        s.offsetSec = off;
        s.restore = swRestore.isChecked();
        s.resume = swResume.isChecked();
        s.imsak = cbImsak.isChecked();
        s.ogle = cbOgle.isChecked();
        s.ikindi = cbIkindi.isChecked();
        s.aksam = cbAksam.isChecked();
        s.yatsi = cbYatsi.isChecked();
        s.sela = cbSela.isChecked();
        s.cumaSela = cbCumaSela.isChecked();
        s.selaMin = Math.max(5, Math.min(120, parseInt(etSelaMin.getText().toString(), 20)));
        s.cumaSelaMin = Math.max(5, Math.min(120, parseInt(etCumaMin.getText().toString(), 45)));
        s.save(this);
        Profiles.syncActive(this);
        Scheduler.tick(this);
        Ui.toast(this, "Kaydedildi", Toast.LENGTH_SHORT);
        refreshAll();
    }

    // ------------------------------------------------------------------ izinler ve deneme

    private void buildPermissions(LinearLayout root) {
        LinearLayout perms = Ui.card(this);
        perms.addView(Ui.text(this, "İzinler (arka planda çalışması için)", 16, Ui.TEXT, true));

        tvExact = Ui.text(this, "", 13, Ui.TEXT, true);
        perms.addView(tvExact, Ui.matchLp(this, 0, 8, 0, 0));
        Ui.Btn bExact = Ui.button(this, null, "Tam zamanlı alarm izni", Ui.CARD, Ui.TEXT, Color.parseColor("#CBD5E1"));
        bExact.setOnClickListener(v -> openExactAlarmSettings());
        perms.addView(bExact, Ui.matchLp(this, 0, 4, 0, 0));

        tvNotif = Ui.text(this, "", 13, Ui.TEXT, true);
        perms.addView(tvNotif, Ui.matchLp(this, 0, 12, 0, 0));
        Ui.Btn bNotif = Ui.button(this, null, "Bildirim izni", Ui.CARD, Ui.TEXT, Color.parseColor("#CBD5E1"));
        bNotif.setOnClickListener(v -> requestNotifications());
        perms.addView(bNotif, Ui.matchLp(this, 0, 4, 0, 0));

        tvBattery = Ui.text(this, "", 13, Ui.TEXT, true);
        perms.addView(tvBattery, Ui.matchLp(this, 0, 12, 0, 0));
        Ui.Btn bBattery = Ui.button(this, null, "Pil kısıtlaması ayarları", Ui.CARD, Ui.TEXT, Color.parseColor("#CBD5E1"));
        bBattery.setOnClickListener(v -> openBatterySettings());
        perms.addView(bBattery, Ui.matchLp(this, 0, 4, 0, 0));

        TextView hint = Ui.text(this, "Xiaomi, Huawei, Samsung, Oppo gibi telefonlarda ayrıca \"otomatik başlat / arka planda "
                + "çalışsın\" iznini açın.", 11, Ui.MUTED, false);
        perms.addView(hint, Ui.matchLp(this, 0, 10, 0, 0));
        root.addView(perms, Ui.matchLp(this, 0, 14, 0, 0));

        LinearLayout test = Ui.card(this);
        test.addView(Ui.text(this, "Deneme", 16, Ui.TEXT, true));
        test.addView(Ui.text(this, "Müzik veya video başlatın, düğmeye basın. 3 saniye sonra sessizlik başlar ve ayarlı süre "
                + "kadar sürer (en fazla 120 sn). Ekranı kilitleyerek de deneyin.", 12, Ui.MUTED, false),
                Ui.matchLp(this, 0, 4, 0, 0));
        Ui.Btn bTest = Ui.button(this, "play", "Denemeyi başlat", Ui.AMBER_BG, Ui.AMBER, 0);
        bTest.setOnClickListener(v -> {
            startTest();
            refreshAll();
        });
        test.addView(bTest, Ui.matchLp(this, 0, 10, 0, 0));
        root.addView(test, Ui.matchLp(this, 0, 14, 0, 0));
    }

    private void refreshPermissions() {
        setPerm(tvExact, "Tam zamanlı alarm", Scheduler.canScheduleExact(this));
        NotificationManager nm = getSystemService(NotificationManager.class);
        setPerm(tvNotif, "Bildirimler", nm.areNotificationsEnabled());
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        setPerm(tvBattery, "Pil kısıtlaması yok (önerilir)", pm.isIgnoringBatteryOptimizations(getPackageName()));
    }

    private void setPerm(TextView tv, String label, boolean ok) {
        tv.setText(I18n.t((ok ? "✓ " : "✗ ") + label));
        tv.setTextColor(ok ? Ui.GREEN_MID : Ui.AMBER);
    }

    private static int parseInt(String v, int fallback) {
        try {
            return Integer.parseInt(v.trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }
}
