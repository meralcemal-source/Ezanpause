package app.ezanpause;

import android.app.NotificationManager;
import android.content.Context;
import android.os.PowerManager;

import java.util.ArrayList;
import java.util.List;

/** "Pro için yapılması gerekenler" listesi: gerçek kurulum durumuna bakar. */
final class ProItems {
    static final class Item {
        final String title;
        final String hint;
        final String action;
        final boolean done;

        Item(String title, String hint, String action, boolean done) {
            this.title = title;
            this.hint = hint;
            this.action = action;
            this.done = done;
        }
    }

    private ProItems() {}

    static List<Item> items(Context c) {
        Settings s = Settings.load(c);
        List<Item> out = new ArrayList<>();

        boolean named = false;
        for (Profiles.P p : Profiles.list(c)) if (!Profiles.DEFAULT_NAME.equals(p.name)) named = true;
        out.add(new Item("Kendi profilinizi oluşturun", "Ayarlar > Kullanıcı profilleri", "profile", named));

        out.add(new Item("Şehrinizi seçin", "Listeden seçin veya GPS ile bulun", "city",
                Settings.prefs(c).getBoolean("city_chosen", false)));

        out.add(new Item("Tam zamanlı alarm izni", "Sessizlik ezan saatinde başlasın", "exact", Scheduler.canScheduleExact(c)));

        NotificationManager nm = c.getSystemService(NotificationManager.class);
        out.add(new Item("Bildirim izni", "Sessizlik sürerken bilgi gösterilir", "notif",
                nm != null && nm.areNotificationsEnabled()));

        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        out.add(new Item("Pil kısıtlamasını kaldırın", "Arka planda kapanmasın", "battery",
                pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName())));

        out.add(new Item("Denemeyi bir kez çalıştırın", "Müzik açıkken sesin kesildiğini görün", "test",
                Settings.prefs(c).getBoolean("test_done", false)));

        out.add(new Item("En az bir vakti açın", "Otomatik sessiz açık ve vakit seçili olsun", "prayers",
                s.enabled && s.prayerCount() > 0));
        return out;
    }

    static int doneCount(List<Item> items) {
        int n = 0;
        for (Item i : items) if (i.done) n++;
        return n;
    }
}
