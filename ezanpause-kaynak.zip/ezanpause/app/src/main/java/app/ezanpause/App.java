package app.ezanpause;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

import java.io.PrintWriter;
import java.io.StringWriter;

/** Uygulama çökerse hata metnini saklar; sonraki açılışta kullanıcıya gösterilir (geliştiriciye iletmek için). */
public class App extends Application {
    private static final String PREFS = "ezanpause_state";
    private static final String KEY = "last_crash";

    @Override
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                String text = sw.toString();
                if (text.length() > 4000) text = text.substring(0, 4000);
                getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, text).commit();
            } catch (Throwable ignored) {
            }
            if (old != null) old.uncaughtException(t, e);
        });
    }

    static String lastCrash(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null);
    }

    static void clearCrash(Context c) {
        SharedPreferences p = c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        p.edit().remove(KEY).apply();
    }
}
