package app.ezanpause;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Dil desteği (Türkçe / English). Uygulamadaki Türkçe metinler ekranda gösterilirken,
 * dil İngilizce ise bu sözlükle çevrilir. Sözlükte olmayan metin olduğu gibi (Türkçe) kalır.
 */
final class I18n {
    private static final String PREF = "ezanpause_lang";
    private static String lang = null; // "tr" | "en"
    private static final Map<String, String> MAP = new HashMap<>();
    private static Pattern pattern;

    private I18n() {
    }

    static boolean isChosen(Context c) {
        return prefs(c).getString("lang", null) != null;
    }

    static void init(Context c) {
        String l = prefs(c).getString("lang", null);
        // Seçim yapılmadıysa telefon diline bak: Türkçe ise Türkçe, değilse İngilizce.
        lang = l != null ? l : ("tr".equals(java.util.Locale.getDefault().getLanguage()) ? "tr" : "en");
    }

    static boolean isEnglish() {
        return "en".equals(lang);
    }

    static void set(Context c, String l) {
        prefs(c).edit().putString("lang", l).apply();
        lang = l;
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    static String[] tAll(String[] in) {
        String[] out = new String[in.length];
        for (int i = 0; i < in.length; i++) out[i] = t(in[i]);
        return out;
    }

    /** Dil İngilizceyse çevirir; değilse metni aynen döndürür. */
    static String t(CharSequence in) {
        if (in == null) return null;
        String s = in.toString();
        if (!isEnglish() || s.isEmpty()) return s;
        String ex = GuideEn.M.get(s);
        if (ex != null) return ex;
        ensure();
        Matcher m = pattern.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String en = MAP.get(m.group());
            m.appendReplacement(sb, Matcher.quoteReplacement(en == null ? m.group() : en));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    private static synchronized void ensure() {
        if (pattern != null) return;
        fill();
        List<String> keys = new ArrayList<>(MAP.keySet());
        Collections.sort(keys, (a, b) -> b.length() - a.length());
        StringBuilder re = new StringBuilder();
        for (String k : keys) {
            if (re.length() > 0) re.append('|');
            char first = k.charAt(0);
            char last = k.charAt(k.length() - 1);
            if (Character.isLetterOrDigit(first)) re.append("(?<![\\p{L}\\p{N}])");
            re.append(Pattern.quote(k));
            if (Character.isLetterOrDigit(last)) re.append("(?![\\p{L}\\p{N}])");
        }
        pattern = Pattern.compile(re.toString());
    }

    private static void a(String tr, String en) {
        MAP.put(tr, en);
    }

    private static void fill() {
        // Vakitler
        a("İmsak / Sabah", "Fajr / Morning");
        a("İmsak", "Fajr"); a("Güneş", "Sunrise"); a("Öğle", "Dhuhr"); a("İkindi", "Asr");
        a("Akşam", "Maghrib"); a("Yatsı", "Isha");
        a("Cuma Selâsı", "Friday Sala"); a("Perşembe Selâsı", "Thursday Sala");
        a("Elle", "Manual"); a("Deneme", "Test");
        a("Fecr vakti, oruç başlama anı", "Dawn; the fast begins");
        a("Güneş doğuşu, kerahat vakti", "Sunrise; prayer is disliked now");
        a("Zeval sonrası, öğle namazı vakti", "Sun past its zenith; Dhuhr time");
        a("Öğle vaktinin çıkışı, ikindi vakti", "Dhuhr ends; Asr time");
        a("Güneş batışı, iftar vakti", "Sunset; time to break the fast");
        a("Şafağın kaybolması, yatsı vakti", "Twilight fades; Isha time");
        // Ana ekran
        a("Namaz Vakitleri & Akıllı Sessiz", "Prayer Times & Smart Silence");
        a("Diyanet Takvimi", "Diyanet calendar");
        a("SIRADAKİ VAKİT", "NEXT PRAYER"); a("kaldı", "left");
        a("Otomatik EzanPause", "Automatic EzanPause");
        a("Tüm izinler tamam", "All permissions granted");
        a("Sessizi Test Et", "Test silence");
        a("GÜNLÜK VAKİTLER", "DAILY TIMES");
        a("Cuma namazı", "Friday prayer"); a("Cuma", "Friday"); a("Perşembe", "Thursday");
        a("Dualar ve sûreler", "Prayers & surahs");
        a("Son sessizlikler", "Recent silences");
        a("Sessizlik bitirildi", "Silence ended");
        a("Ezan sessizliği sürüyor, süre bitince ses açılır", "Adhan silence in progress; sound returns when it ends");
        a("sessizlik başladı", "of silence started");
        a("Şu anki vakit", "Current prayer");
        a("Namazlarda otomatik sessiz devrede", "Auto-silence is on for prayers");
        a("Kapalı", "Off");
        a("Namaz vaktinde medya sesi otomatik kapatılır", "Media sound is muted automatically at prayer time");
        a("sonra ses normale döner", "then sound returns to normal");
        a("Ezandan", "Starts"); a("önce başlar", "before the adhan");
        a("Şu an sessizde", "Silent now"); a("kalan", "remaining");
        a("Sessizliği Bitir", "End silence");
        a("Ezan sessizliği sürüyor", "Adhan silence in progress");
        a("EzanPause Başlat", "Start EzanPause"); a("sessiz", "silent");
        a("İzinler Tamam", "Permissions OK"); a("İzinleri Ver", "Grant permissions");
        a("Henüz kayıt yok.", "No records yet.");
        a("VAKİTTE", "NOW"); a("SIRADAKİ", "NEXT");
        a("Sessizi hemen başlat veya bitir", "Start or end silence now");
        a("Ayarlar", "Settings"); a("Geri", "Back");
        // Süre
        a("sn", "sec"); a("dk", "min");
        // Ayarlar
        a("Pro için yapılması gerekenler", "Steps to get ready for Pro");
        a("Pro ekranını aç", "Open Pro screen"); a("tamamlandı", "completed");
        a("Kullanıcı profilleri", "User profiles");
        a("Her profilin kendi şehri, sessizlik süresi ve vakit seçimi vardır.", "Each profile has its own city, silence length and prayer selection.");
        a("Örneğin Ev, İş, Cami.", "For example Home, Work, Mosque.");
        a("Yeni profil", "New profile"); a("Profil adı", "Profile name"); a("Profil", "Profile");
        a("Varsayılan", "Default");
        a("silinsin mi?", "— delete it?"); a("Sil", "Delete"); a("Vazgeç", "Cancel");
        a("En az bir profil kalmalı", "At least one profile must remain");
        a("Tamam", "OK"); a("AKTİF", "ACTIVE"); a("Seç", "Select"); a("etkin", "active");
        a("vakit", "prayers");
        a("Namaz ayarları", "Prayer settings");
        a("Ezan vaktinde otomatik sessize al", "Mute automatically at prayer time");
        a("Şehir", "City");
        a("Konumdan bul (GPS)", "Find by location (GPS)"); a("Konumdan bul", "Find by location");
        a("Sessizlik süresi (saniye)", "Silence length (seconds)");
        a("örn.", "e.g.");
        a("Ezandan kaç saniye ÖNCE başlasın (0 = tam vaktinde)", "Seconds BEFORE the adhan to start (0 = exactly on time)");
        a("Bitince sesi geri aç", "Restore sound when finished");
        a("Çalan müziği duraklat, bitince devam ettir", "Pause playing music and resume when finished");
        a("Hangi vakitlerde", "Which prayers");
        a("Perşembe akşamı selâsı (yatsı ezanından önce) – bazı yörelerde gelenek", "Thursday evening sala (before the Isha adhan) – a custom in some regions");
        a("Cuma selâsı (Cuma günü, öğle ezanından önce)", "Friday sala (on Friday, before the noon adhan)");
        a("Cuma selâsı öğle ezanından kaç dakika önce okunuyor? (çoğu yerde 30–60)", "Minutes before the noon adhan that the Friday sala is recited (usually 30–60)");
        a("Perşembe selâsı yatsı ezanından kaç dakika önce okunuyor? (çoğu yerde 15–30)", "Minutes before the Isha adhan that the Thursday sala is recited (usually 15–30)");
        a("Kaydet", "Save"); a("Kaydedildi", "Saved");
        a("Süre 1 ile", "Length must be between 1 and"); a("saniye arasında olmalı", "seconds");
        a("Öncesi 0 ile", "Lead time must be between 0 and");
        a("İzinler (arka planda çalışması için)", "Permissions (to work in the background)");
        a("Xiaomi, Huawei, Samsung, Oppo gibi telefonlarda ayrıca \"otomatik başlat / arka planda çalışsın\" iznini açın.",
                "On Xiaomi, Huawei, Samsung, Oppo phones also enable \"autostart / run in background\".");
        a("Müzik veya video başlatın, düğmeye basın. 3 saniye sonra sessizlik başlar ve ayarlı süre kadar sürer (en fazla 120 sn). Ekranı kilitleyerek de deneyin.",
                "Start music or a video and press the button. Silence begins after 3 seconds and lasts for the set length (max 120 sec). Try it with the screen locked too.");
        a("Denemeyi başlat", "Start test");
        a("Tam zamanlı alarm", "Exact alarm"); a("Bildirimler", "Notifications");
        a("Pil kısıtlaması yok (önerilir)", "No battery restriction (recommended)");
        a("Dil / Language", "Language"); a("Dil", "Language");
        // Pro
        a("EzanPause Pro", "EzanPause Pro");
        a("Pro'yu etkinleştir", "Activate Pro"); a("Önce listeyi tamamlayın", "Complete the list first");
        a("Pro satın alma, uygulama Google Play'de yayınlanınca açılacak. Hazırlıkların tamam!", "Pro purchase will open once the app is published on Google Play. Your setup is ready!");
        a("Bu liste kurulumun gerçek durumuna bakar: izin verdiğinizde ve ayarları yaptığınızda maddeler kendiliğinden işaretlenir. Satın alma henüz bağlı değildir.",
                "This list reflects the real state of your setup: items are checked automatically when you grant permissions and adjust settings. Purchase is not connected yet.");
        a("Yap", "Do it");
        a("Kendi profilinizi oluşturun", "Create your own profile");
        a("Ayarlar > Kullanıcı profilleri", "Settings > User profiles");
        a("Şehrinizi seçin", "Choose your city");
        a("Listeden seçin veya GPS ile bulun", "Pick from the list or find with GPS");
        a("Sessizlik ezan saatinde başlasın", "So silence starts at adhan time");
        a("Bildirim izni", "Notification permission");
        a("Sessizlik sürerken bilgi gösterilir", "Shows info while silence is active");
        a("Pil kısıtlamasını kaldırın", "Remove battery restriction");
        a("Arka planda kapanmasın", "So it is not closed in the background");
        a("Denemeyi bir kez çalıştırın", "Run the test once");
        a("Müzik açıkken sesin kesildiğini görün", "See the sound cut while music plays");
        a("En az bir vakti açın", "Turn on at least one prayer");
        a("Otomatik sessiz açık ve vakit seçili olsun", "Auto-silence on and a prayer selected");
        a("Tam zamanlı alarm izni", "Exact alarm permission");
        // Dialoglar
        a("Ülke seç", "Select country"); a("şehir seç", "select city");
        a("Konum aranıyor…", "Finding location…");
        a("Konum alınamadı. Konum (GPS) servisinin açık olduğundan emin olun; olmazsa şehri listeden seçin.",
                "Could not get location. Make sure location (GPS) is on; otherwise pick the city from the list.");
        a("Bulunan şehir", "City found"); a("yaklaşık", "about");
        a("Uyarı: kayıtlı en yakın şehir uzakta; vakitler birkaç dakika farklı olabilir.", "Warning: the nearest saved city is far away; times may differ by a few minutes.");
        a("Konum izni verilmedi. Şehri listeden seçebilirsiniz.", "Location permission denied. You can pick the city from the list.");
        a("Bu bölüm aşağıda", "This section is below");
        a("Uygulama geçen sefer hata verdi", "The app reported an error last time");
        a("Kopyala", "Copy"); a("Kapat", "Close");
        a("Kopyalandı. Bana yapıştırın.", "Copied. Paste it to the developer.");
        a("sonra", "later"); a("sessizlik", "silence");
        a("Medya sesi ezan için kapalı", "Media sound is muted for the adhan");
        // Hesap
        a("Giriş yapın veya yeni hesap oluşturun", "Sign in or create a new account");
        a("E-posta", "Email"); a("Şifre (en az 6 karakter)", "Password (at least 6 characters)");
        a("Giriş yap", "Sign in"); a("Yeni hesap oluştur", "Create new account"); a("Şifremi unuttum", "Forgot password");
        a("Lütfen bekleyin…", "Please wait…"); a("E-posta ve şifre yazın.", "Enter email and password.");
        a("Önce e-posta adresinizi yazın.", "Enter your email address first.");
        a("Ücretsiz hesap 1 cihazda, Pro hesap en fazla 5 cihazda kullanılabilir. Otomatik ezan sessizi Pro hesaplarda çalışır.",
                "A free account works on 1 device, a Pro account on up to 5 devices. Automatic adhan silence works on Pro accounts.");
        a("Cihaz sınırı doldu. Hangi cihazı çıkaralım?", "Device limit reached. Which device should we remove?");
        a("Cihazlarım — çıkarmak için dokunun", "My devices — tap to remove");
        a("Cihazlarım", "My devices"); a("Cihaz sınırı", "Device limit"); a("Cihaz çıkarıldı", "Device removed");
        a("(bu cihaz)", "(this device)");
        a("Bu cihaz hesaptan çıkarıldı. Yeniden giriş yapın.", "This device was removed from the account. Sign in again.");
        a("Hesabım", "My account"); a("Çıkış yap", "Sign out"); a("Plan", "Plan"); a("Ücretsiz", "Free");
        a("Giriş yapılmadı", "Not signed in"); a("Pro (sınırsız)", "Pro (unlimited)"); a("tarihine kadar", "until");
        a("Pro planları", "Pro plans");
        a("7 gün ücretsiz · sonra aylık veya yıllık abonelik", "7 days free · then a monthly or yearly subscription");
        a("Pro: ezan vaktinde otomatik sessiz + 5 cihaza kadar kullanım. Fiyat, Google Play'de bulunduğunuz ülkenin parasıyla gösterilir. Satın alma Google Play yayınından sonra buradan yapılacak.",
                "Pro: automatic silence at adhan time + use on up to 5 devices. The price is shown in your country's currency by Google Play. Purchase will be available here after the Google Play release.");
        a("Bu e-posta ile zaten bir hesap var. Giriş yapın.", "An account with this email already exists. Sign in.");
        a("E-posta veya şifre hatalı.", "Wrong email or password.");
        a("Şifre en az 6 karakter olmalı.", "Password must be at least 6 characters.");
        a("E-posta adresi geçersiz.", "Invalid email address.");
        a("Çok fazla deneme yapıldı. Biraz bekleyip tekrar deneyin.", "Too many attempts. Wait a moment and try again.");
        a("Bağlantı kurulamadı. İnternetinizi kontrol edin.", "Could not connect. Check your internet.");
        a("İşlem yapılamadı. İnternetinizi kontrol edin.", "Action failed. Check your internet.");
        a("İşlem yapılamadı.", "Action failed.");
        a("Şifre sıfırlama bağlantısı e-posta adresinize gönderildi.", "A password reset link was sent to your email.");
        a("Oturum süresi doldu, yeniden giriş yapın.", "Session expired, sign in again.");
        a("Bu hesap devre dışı bırakılmış.", "This account is disabled.");
        a("Kullanıcı bilgileri", "User information");
        a("Satın almak için önce giriş yapın.", "Sign in first to subscribe.");
        a("Aylık", "Monthly"); a("Yıllık", "Yearly"); a("yükleniyor…", "loading…"); a("yok", "unavailable");
        a("7 gün ücretsiz, sonra", "7 days free, then");
        a("Pro etkin. Teşekkürler!", "Pro is active. Thank you!");
        a("Satın alma iptal edildi.", "Purchase cancelled."); a("Satın alma tamamlanamadı.", "Purchase could not be completed.");
        a("Google Play'e bağlanılamadı.", "Could not connect to Google Play.");
        a("Fiyatlar henüz yüklenmedi. Biraz bekleyip tekrar deneyin.", "Prices are not loaded yet. Wait a moment and try again.");
        a("Bu plan şu an satın alınamıyor.", "This plan cannot be purchased right now.");
        a("Planlar şu an yüklenemedi. Daha sonra tekrar deneyin.", "Plans could not be loaded. Try again later.");
        a("Pro (Google Play)", "Pro (Google Play)");
        a("Hesabım ve Pro", "My account & Pro");
        a("Giriş yap / Kayıt ol", "Sign in / Sign up");
        a("Ücretsiz plan hesap gerektirmez. Pro için giriş yapın veya hesap oluşturun.", "The free plan needs no account. Sign in or sign up for Pro.");
        a("Ücretsiz plan hesap gerektirmez. Pro'ya geçmek ve otomatik sessizi kullanmak için giriş yapın veya hesap oluşturun.", "The free plan needs no account. Sign in or sign up to go Pro and use automatic silence.");
        a("Hesap olmadan devam et (ücretsiz)", "Continue without an account (free)");
        a("Otomatik sessiz Pro hesaba özel (Pro ekranından giriş yapın)", "Automatic silence is Pro-only (sign in from the Pro screen)");
        a("Doğrulama e-postası gönder", "Send verification email");
        a("Doğrulama bağlantısı e-posta adresinize gönderildi.", "A verification link was sent to your email.");
        a("Hesabımı sil", "Delete my account"); a("Hesap silinsin mi?", "Delete account?");
        a("Hesabınız, planınız ve cihaz kayıtlarınız kalıcı olarak silinir. Bu işlem geri alınamaz.", "Your account, plan and device records will be permanently deleted. This cannot be undone.");
        a("Hesabınız silindi", "Your account was deleted");
        a("Not: Anlatım Hanefî mezhebine ve Diyanet ilmihaline göredir. Kesin hüküm ve özel durumlar için ilmihale veya il/ilçe müftülüğüne başvurun.",
                "Note: The explanation follows the Hanafi school and the Diyanet catechism. For definitive rulings and special cases consult a catechism or your local mufti's office.");
        a("Namazda okunan dualar; Arapçası, okunuşu ve anlamıyla.", "Prayers recited in the salah; in Arabic, transliteration and meaning.");
        a("sünnet + farz + vacip", "sunnah + fard + wajib"); a("sünnet + farz", "sunnah + fard");
        a("Farz", "Fard");
        a("Bu ekran açılamadı. Aşağıdaki yazıyı kopyalayıp geliştiriciye iletin:", "This screen could not be opened. Copy the text below and send it to the developer:");
        // Hicri ve tarih
        a("Muharrem", "Muharram"); a("Safer", "Safar"); a("Rebiülevvel", "Rabi' al-awwal"); a("Rebiülahir", "Rabi' al-thani");
        a("Cemaziyelevvel", "Jumada al-awwal"); a("Cemaziyelahir", "Jumada al-thani"); a("Recep", "Rajab");
        a("Şaban", "Sha'ban"); a("Ramazan", "Ramadan"); a("Şevval", "Shawwal"); a("Zilkade", "Dhu al-Qa'dah"); a("Zilhicce", "Dhu al-Hijjah");
        a("Ocak", "January"); a("Şubat", "February"); a("Mart", "March"); a("Nisan", "April"); a("Mayıs", "May");
        a("Haziran", "June"); a("Temmuz", "July"); a("Ağustos", "August"); a("Eylül", "September"); a("Ekim", "October");
        a("Kasım", "November"); a("Aralık", "December");
        a("Pazartesi", "Monday"); a("Salı", "Tuesday"); a("Çarşamba", "Wednesday");
        a("Cumartesi", "Saturday"); a("Pazar", "Sunday");
        // Rehber başlıkları
        a("Rekât özeti", "Rakat summary"); a("rekât", "rakat"); a("Toplam", "Total");
        a("Bu bölümde okunanlar", "Recited in this section");
        a("Okunan dualar ve sûreler", "Prayers and surahs recited");
        a("OKUNUŞU", "TRANSLITERATION"); a("ANLAMI", "MEANING");
    }
}
