package app.ezanpause;

import java.time.LocalDate;
import java.time.chrono.HijrahDate;
import java.time.temporal.ChronoField;

/** Hicri tarih gösterimi (Ümmülkurâ takvimi; Diyanet ile bir gün fark edebilir). */
final class Hijri {
    private static final String[] MONTHS = {"Muharrem", "Safer", "Rebiülevvel", "Rebiülahir", "Cemaziyelevvel",
            "Cemaziyelahir", "Recep", "Şaban", "Ramazan", "Şevval", "Zilkade", "Zilhicce"};
    private static final String[] MONTHS_TR = {"Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz",
            "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"};
    private static final String[] DAYS = {"Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"};

    private Hijri() {}

    static String hijri(LocalDate d) {
        try {
            HijrahDate h = HijrahDate.from(d);
            int m = h.get(ChronoField.MONTH_OF_YEAR);
            return h.get(ChronoField.DAY_OF_MONTH) + " " + MONTHS[m - 1] + " " + h.get(ChronoField.YEAR) + " AH";
        } catch (RuntimeException e) {
            return "";
        }
    }

    static String gregorian(LocalDate d) {
        return String.format("%02d %s %d, %s", d.getDayOfMonth(), MONTHS_TR[d.getMonthValue() - 1], d.getYear(),
                DAYS[d.getDayOfWeek().getValue() - 1]);
    }
}
