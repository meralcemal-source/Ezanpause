package app.ezanpause;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.LinkedHashSet;

/**
 * Bir vakte dokununca açılan bilgi ekranı: rekât sayısı, sünnet/farz/vacip ayrımı, hangi rekâtta ne okunduğu
 * ve okunan dualar (Arapça, okunuşu, anlamı). extra "key" = imsak|gunes|ogle|ikindi|aksam|yatsi|cuma|dualar.
 */
public class GuideActivity extends BaseActivity {
    static final String EXTRA_KEY = "key";

    private LinearLayout root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String key = getIntent().getStringExtra(EXTRA_KEY);
        if (key == null) key = "ogle";
        root = screen();
        try {
            if ("dualar".equals(key)) {
                topBar(root, "Dualar ve sûreler");
                buildDuaList();
            } else {
                PrayerGuide.Prayer p = PrayerGuide.prayer(key);
                topBar(root, p.title);
                buildPrayer(p);
            }
        } catch (Throwable t) {
            // Çökmek yerine hatayı ekranda göster (kopyalayıp iletilebilir).
            java.io.StringWriter sw = new java.io.StringWriter();
            t.printStackTrace(new java.io.PrintWriter(sw));
            TextView err = Ui.text(this, "Bu ekran açılamadı. Aşağıdaki yazıyı kopyalayıp geliştiriciye iletin:\n\n" + sw,
                    11, Ui.WARN_RED, false);
            err.setTextIsSelectable(true);
            root.addView(err);
        }
    }

    // ------------------------------------------------------------------ vakit sayfası

    private void buildPrayer(PrayerGuide.Prayer p) {
        int total = p.totalRekat();
        if (total > 0) {
            LinearLayout hero = card();
            TextView big = Ui.text(this, "Toplam " + total + " rekât", 24, Ui.GREEN, true);
            hero.addView(big);
            hero.addView(Ui.text(this, p.key.equals("yatsi") ? "sünnet + farz + vacip" : "sünnet + farz", 12, Ui.MUTED, false));
            root.addView(hero, Ui.matchLp(this, 0, 6, 0, 0));
        }

        LinearLayout info = card();
        info.addView(Ui.text(this, p.timeInfo, 14, Ui.TEXT, false));
        TextView note = Ui.text(this, p.note, 12, Ui.MUTED, false);
        note.setLineSpacing(0, 1.15f);
        info.addView(note, Ui.matchLp(this, 0, 8, 0, 0));
        root.addView(info, Ui.matchLp(this, 0, 12, 0, 0));

        if (!p.parts.isEmpty()) {
            LinearLayout sum = card();
            sum.addView(Ui.text(this, "Rekât özeti", 16, Ui.TEXT, true));
            for (PrayerGuide.Part part : p.parts) {
                LinearLayout line = Ui.row(this);
                TextView left = Ui.text(this, part.name, 13, Ui.TEXT, false);
                line.addView(left, Ui.weightLp(this, 1f, 0, 0, 8, 0));
                TextView right = Ui.text(this, part.rekat + " · " + part.ruling, 12,
                        part.ruling.startsWith("Farz") ? Ui.GREEN : Ui.AMBER, true);
                line.addView(right);
                sum.addView(line, Ui.matchLp(this, 0, 8, 0, 0));
            }
            root.addView(sum, Ui.matchLp(this, 0, 12, 0, 0));

            for (PrayerGuide.Part part : p.parts) {
                LinearLayout c = card();
                c.addView(Ui.text(this, part.name + " · " + part.rekat + " rekât", 16, Ui.TEXT, true));
                c.addView(Ui.text(this, part.ruling, 12, Ui.AMBER, true));
                for (String step : part.steps) {
                    TextView t = Ui.text(this, step, 13, Ui.TEXT, false);
                    t.setLineSpacing(0, 1.2f);
                    c.addView(t, Ui.matchLp(this, 0, 10, 0, 0));
                }
                c.addView(Ui.text(this, "Bu bölümde okunanlar", 11, Ui.MUTED, true), Ui.matchLp(this, 0, 12, 0, 0));
                StringBuilder sb = new StringBuilder();
                for (String id : part.duaIds) {
                    PrayerGuide.Dua d = PrayerGuide.dua(id);
                    if (d != null) {
                        if (sb.length() > 0) sb.append(" · ");
                        sb.append(d.name);
                    }
                }
                c.addView(Ui.text(this, sb.toString(), 12, Ui.GREEN, false), Ui.matchLp(this, 0, 2, 0, 0));
                root.addView(c, Ui.matchLp(this, 0, 12, 0, 0));
            }

            root.addView(Ui.text(this, "Okunan dualar ve sûreler", 18, Ui.TEXT, true), Ui.matchLp(this, 4, 22, 0, 0));
            LinkedHashSet<String> seen = new LinkedHashSet<>();
            for (PrayerGuide.Part part : p.parts) java.util.Collections.addAll(seen, part.duaIds);
            for (String id : seen) {
                PrayerGuide.Dua d = PrayerGuide.dua(id);
                if (d != null) root.addView(duaCard(d), Ui.matchLp(this, 0, 12, 0, 0));
            }
        }

        TextView foot = Ui.text(this, "Not: Anlatım Hanefî mezhebine ve Diyanet ilmihaline göredir. Kesin hüküm ve özel durumlar "
                + "için ilmihale veya il/ilçe müftülüğüne başvurun.", 11, Ui.MUTED, false);
        root.addView(foot, Ui.matchLp(this, 4, 18, 4, 0));
    }

    private void buildDuaList() {
        TextView sub = Ui.text(this, "Namazda okunan dualar; Arapçası, okunuşu ve anlamıyla.", 13, Ui.MUTED, false);
        root.addView(sub, Ui.matchLp(this, 4, 0, 0, 4));
        for (PrayerGuide.Dua d : PrayerGuide.DUAS) root.addView(duaCard(d), Ui.matchLp(this, 0, 12, 0, 0));
    }

    private LinearLayout duaCard(PrayerGuide.Dua d) {
        LinearLayout c = card();
        c.addView(Ui.text(this, d.name, 16, Ui.TEXT, true));
        c.addView(Ui.text(this, d.when, 12, Ui.AMBER, false));

        TextView ar = Ui.text(this, d.arabic, 22, Ui.TEXT, false);
        ar.setTextDirection(View.TEXT_DIRECTION_RTL);
        ar.setGravity(Gravity.END);
        ar.setLineSpacing(0, 1.4f);
        ar.setBackground(Ui.shape(this, Color.parseColor("#F0FDF4"), 14, Color.parseColor("#BBF7D0"), 1));
        ar.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10));
        c.addView(ar, Ui.matchLp(this, 0, 10, 0, 0));

        c.addView(Ui.text(this, "OKUNUŞU", 10, Ui.MUTED, true), Ui.matchLp(this, 0, 12, 0, 0));
        TextView tr = Ui.text(this, d.translit, 13, Ui.GREEN, false);
        tr.setLineSpacing(0, 1.2f);
        c.addView(tr, Ui.matchLp(this, 0, 2, 0, 0));
        c.addView(Ui.text(this, "ANLAMI", 10, Ui.MUTED, true), Ui.matchLp(this, 0, 12, 0, 0));
        TextView mean = Ui.text(this, d.meaning, 13, Ui.TEXT, false);
        mean.setLineSpacing(0, 1.2f);
        c.addView(mean, Ui.matchLp(this, 0, 2, 0, 0));
        return c;
    }

    /** Kartı ana sütuna eklemeden üretir; çağıran ekler. */
    private LinearLayout card() {
        return Ui.card(this);
    }
}
