package app.ezanpause;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** E-posta + şifre ile giriş / kayıt. Giriş yapılmadan uygulama kullanılamaz. */
public class LoginActivity extends BaseActivity {
    private EditText etMail;
    private EditText etPass;
    private TextView tvMsg;
    private Ui.Btn bLogin;
    private Ui.Btn bSignup;
    private boolean busy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!I18n.isChosen(this)) {
            LinearLayout r0 = screen();
            showLanguageDialog(false);
            return;
        }
        LinearLayout root = screen();

        LinearLayout head = Ui.column(this);
        head.setGravity(Gravity.CENTER_HORIZONTAL);
        android.widget.FrameLayout logo = Ui.circleIcon(this, "moon", Color.WHITE, Ui.GREEN, 0, 64, 34);
        logo.setClickable(false);
        head.addView(logo, Ui.lp(this, Ui.dp(this, 64), Ui.dp(this, 64), 0, 24, 0, 0));
        TextView title = Ui.text(this, "EzanPause", 26, Ui.TEXT, true);
        title.setGravity(Gravity.CENTER);
        head.addView(title, Ui.matchLp(this, 0, 12, 0, 0));
        TextView sub = Ui.text(this, "Giriş yapın veya yeni hesap oluşturun", 13, Ui.MUTED, false);
        sub.setGravity(Gravity.CENTER);
        head.addView(sub, Ui.matchLp(this, 0, 4, 0, 0));
        root.addView(head, Ui.matchLp(this, 0, 0, 0, 0));

        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, "E-posta", 12, Ui.MUTED, true));
        etMail = Ui.field(this, "ornek@mail.com", false);
        etMail.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        card.addView(etMail, Ui.matchLp(this, 0, 4, 0, 0));
        card.addView(Ui.text(this, "Şifre (en az 6 karakter)", 12, Ui.MUTED, true), Ui.matchLp(this, 0, 12, 0, 0));
        etPass = Ui.field(this, "••••••", false);
        etPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        card.addView(etPass, Ui.matchLp(this, 0, 4, 0, 0));

        tvMsg = Ui.text(this, "", 12, Ui.WARN_RED, false);
        card.addView(tvMsg, Ui.matchLp(this, 0, 10, 0, 0));

        bLogin = Ui.button(this, "check", "Giriş yap", Ui.GREEN, Color.WHITE, 0);
        bLogin.setOnClickListener(v -> go(false));
        card.addView(bLogin, Ui.matchLp(this, 0, 12, 0, 0));
        bSignup = Ui.button(this, "plus", "Yeni hesap oluştur", Ui.CARD, Ui.TEXT, Ui.LINE);
        bSignup.setOnClickListener(v -> go(true));
        card.addView(bSignup, Ui.matchLp(this, 0, 8, 0, 0));
        TextView forgot = Ui.text(this, "Şifremi unuttum", 13, Ui.GREEN, true);
        forgot.setGravity(Gravity.CENTER);
        forgot.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 4));
        forgot.setOnClickListener(v -> forgot());
        card.addView(forgot);
        root.addView(card, Ui.matchLp(this, 0, 20, 0, 0));

        TextView info = Ui.text(this, "Ücretsiz hesap 1 cihazda, Pro hesap en fazla 5 cihazda kullanılabilir. "
                + "Otomatik ezan sessizi Pro hesaplarda çalışır.", 11, Ui.MUTED, false);
        root.addView(info, Ui.matchLp(this, 4, 14, 4, 0));

        Ui.Btn lang = Ui.button(this, null, "Dil / Language: " + (I18n.isEnglish() ? "English" : "Türkçe"), Ui.CARD, Ui.TEXT, Ui.LINE);
        lang.setOnClickListener(v -> showLanguageDialog(true));
        root.addView(lang, Ui.matchLp(this, 0, 14, 0, 0));
    }

    private void setBusy(boolean b) {
        busy = b;
        bLogin.setEnabled(!b);
        bSignup.setEnabled(!b);
        if (b) tvMsg.setText(I18n.t("Lütfen bekleyin…"));
    }

    private void go(boolean signup) {
        if (busy) return;
        final String mail = etMail.getText().toString().trim();
        final String pass = etPass.getText().toString();
        if (mail.isEmpty() || pass.isEmpty()) {
            tvMsg.setText(I18n.t("E-posta ve şifre yazın."));
            return;
        }
        setBusy(true);
        Account.Callback cb = (ok, msg) -> runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            if (ok && "LIMIT".equals(msg)) {
                setBusy(false);
                tvMsg.setText("");
                askReplaceDevice();
            } else if (ok) {
                finishLogin();
            } else {
                setBusy(false);
                tvMsg.setText(I18n.t(msg));
            }
        });
        if (signup) Account.signUp(this, mail, pass, cb);
        else Account.signIn(this, mail, pass, cb);
    }

    private void finishLogin() {
        Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
        finish();
    }

    /** Cihaz sınırı dolu: hangi cihazın çıkarılacağını sor. */
    private void askReplaceDevice() {
        setBusy(true);
        new Thread(() -> {
            List<Account.Device> list;
            try {
                list = Account.fetchDevices(this);
            } catch (Throwable t) {
                list = new java.util.ArrayList<>();
            }
            final List<Account.Device> devs = list;
            runOnUiThread(() -> {
                setBusy(false);
                tvMsg.setText("");
                if (isFinishing() || isDestroyed()) return;
                final String[] names = new String[devs.size()];
                for (int i = 0; i < names.length; i++) names[i] = devs.get(i).model;
                new AlertDialog.Builder(this)
                        .setTitle(I18n.t("Cihaz sınırı doldu. Hangi cihazı çıkaralım?"))
                        .setItems(names, (d, which) -> {
                            setBusy(true);
                            Account.removeDevice(this, devs.get(which).id, true, (ok, m) -> runOnUiThread(() -> {
                                if (ok) finishLogin();
                                else {
                                    setBusy(false);
                                    tvMsg.setText(I18n.t(m));
                                    Account.signOutLocal(this);
                                }
                            }));
                        })
                        .setNegativeButton(I18n.t("Vazgeç"), (d, w) -> Account.signOutLocal(this))
                        .setOnCancelListener(d -> Account.signOutLocal(this))
                        .show();
            });
        }).start();
    }

    private void forgot() {
        final String mail = etMail.getText().toString().trim();
        if (mail.isEmpty()) {
            tvMsg.setText(I18n.t("Önce e-posta adresinizi yazın."));
            return;
        }
        Account.resetPassword(mail, (ok, msg) -> runOnUiThread(() -> {
            tvMsg.setTextColor(ok ? Ui.GREEN : Ui.WARN_RED);
            tvMsg.setText(I18n.t(msg));
        }));
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}
