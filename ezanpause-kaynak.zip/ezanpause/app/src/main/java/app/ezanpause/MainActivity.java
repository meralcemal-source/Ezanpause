package app.ezanpause;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/** Ana ekran: sıradaki vakit, geri sayım, otomatik sessiz, günlük vakit kartları. */
public class MainActivity extends BaseActivity {
    private static final String[] KEYS = {"imsak", "gunes", "ogle", "ikindi", "aksam", "yatsi"};
    private static final String[] NAMES = {"İmsak", "Güneş", "Öğle", "İkindi", "Akşam", "Yatsı"};
    private static final String[] SUBS = {
            "Fecr vakti, oruç başlama anı", "Güneş doğuşu, kerahat vakti", "Zeval sonrası, öğle namazı vakti",
            "Öğle vaktinin çıkışı, ikindi vakti", "Güneş batışı, iftar vakti", "Şafağın kaybolması, yatsı vakti"};
    private static final String[] ICONS = {"moon", "sunset", "sun", "cloud", "sunset", "moon"};

    private static final class Ev {
        final int idx;
        final long t;

        Ev(int idx, long t) {
            this.idx = idx;
            this.t = t;
        }
    }

    private Settings s;
    private final List<Ev> evs = new ArrayList<>();
    private LocalDate evsDate;
    private String evsCity;
    private long[] todayTimes = new long[6];

    private TextView tvCity;
    private TextView tvDate;
    private TextView tvHijri;
    private TextView tvNextName;
    private TextView tvNextTime;
    private TextView tvCountdown;
    private TextView tvNow;
    private TextView tvSilent;
    private TextView tvAutoSub;
    private TextView tvAutoDesc;
    private TextView tvEvents;
    private Ui.Bar bar;
    private Ui.Btn btnStart;
    private Ui.Btn btnPerm;
    private Switch swAuto;
    private boolean binding;

    private final LinearLayout[] cards = new LinearLayout[6];
    private final TextView[] cardTimes = new TextView[6];
    private final TextView[] cardBadges = new TextView[6];
    private final ImageView[] cardIcons = new ImageView[6];
    private final int[] cardState = {-1, -1, -1, -1, -1, -1};

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        s = Settings.load(this);
        buildUi();
        Scheduler.tick(this);
        showCrashIfAny();
    }

    @Override
    protected void onResume() {
        super.onResume();
        s = Settings.load(this);
        for (int i = 0; i < cardState.length; i++) cardState[i] = -1;
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    // ------------------------------------------------------------------ arayüz

    private void buildUi() {
        LinearLayout root = screen();

        // Üst çubuk: logo, başlık, sağda Pro / Dualar / Ses / Ayarlar
        LinearLayout top = Ui.row(this);
        FrameLayout logo = Ui.circleIcon(this, "moon", Color.WHITE, Ui.GREEN, 0, 40, 22);
        logo.setClickable(false);
        top.addView(logo, Ui.lp(this, Ui.dp(this, 40), Ui.dp(this, 40), 0, 0, 8, 0));

        LinearLayout titles = Ui.column(this);
        titles.addView(Ui.text(this, "EzanPause", 19, Ui.TEXT, true));
        titles.addView(Ui.text(this, "Namaz Vakitleri & Akıllı Sessiz · v1.2.0", 10, Ui.MUTED, false));
        top.addView(titles, Ui.weightLp(this, 1f, 0, 0, 4, 0));

        FrameLayout bPro = Ui.circleIcon(this, "star", Ui.AMBER_LINE, Ui.AMBER_BG, 0, 40, 22);
        bPro.setContentDescription("Pro");
        bPro.setOnClickListener(v -> startActivity(new Intent(this, ProActivity.class)));
        FrameLayout bBook = Ui.circleIcon(this, "book", Ui.TEXT, Ui.CARD, Ui.LINE, 40, 20);
        bBook.setContentDescription("Dualar ve sûreler");
        bBook.setOnClickListener(v -> openGuide("dualar"));
        FrameLayout bSpeaker = Ui.circleIcon(this, "speaker", Ui.TEXT, Ui.CARD, Ui.LINE, 40, 20);
        bSpeaker.setContentDescription("Sessizi hemen başlat veya bitir");
        bSpeaker.setOnClickListener(v -> toggleManual());
        FrameLayout bGear = Ui.circleIcon(this, "gear", Ui.TEXT, Ui.CARD, Ui.LINE, 40, 20);
        bGear.setContentDescription("Ayarlar");
        bGear.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        FrameLayout[] icons = {bPro, bBook, bSpeaker, bGear};
        for (FrameLayout f : icons) top.addView(f, Ui.lp(this, Ui.dp(this, 40), Ui.dp(this, 40), 3, 0, 0, 0));
        root.addView(top, Ui.matchLp(this, 0, 4, 0, 0));

        // Şehir satırı
        LinearLayout cityRow = Ui.row(this);
        cityRow.setClickable(true);
        cityRow.setOnClickListener(v -> showCityDialog(() -> {
            s = Settings.load(this);
            refresh();
        }, (text, found) -> Toast.makeText(this, text, Toast.LENGTH_LONG).show()));
        cityRow.addView(Ui.icon(this, "pin", Ui.GREEN, 18), Ui.lp(this, Ui.dp(this, 18), Ui.dp(this, 18), 0, 0, 6, 0));
        tvCity = Ui.text(this, "", 15, Ui.TEXT, true);
        cityRow.addView(tvCity);
        cityRow.addView(Ui.text(this, "  ▾", 14, Ui.MUTED, false));
        cityRow.addView(new View(this), Ui.weightLp(this, 1f, 0, 0, 0, 0));
        cityRow.addView(Ui.text(this, "Diyanet Takvimi", 11, Ui.MUTED, false));
        cityRow.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 4));
        root.addView(cityRow, Ui.matchLp(this, 2, 4, 2, 4));

        // Geri sayım kartı
        LinearLayout hero = Ui.column(this);
        GradientDrawable heroBg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor("#DDF7EA"), Color.WHITE});
        heroBg.setCornerRadius(Ui.dp(this, 26));
        heroBg.setStroke(Ui.dp(this, 1), Color.parseColor("#BBF7D0"));
        hero.setBackground(heroBg);
        hero.setPadding(Ui.dp(this, 18), Ui.dp(this, 16), Ui.dp(this, 18), Ui.dp(this, 18));

        LinearLayout dateRow = Ui.row(this);
        tvDate = Ui.text(this, "", 11, Ui.TEXT, true);
        dateRow.addView(tvDate, Ui.weightLp(this, 1f, 0, 0, 8, 0));
        tvHijri = Ui.text(this, "", 11, Ui.AMBER, true);
        tvHijri.setBackground(Ui.shape(this, Color.parseColor("#FFF7ED"), 14, Ui.AMBER_LINE, 1));
        tvHijri.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4));
        dateRow.addView(tvHijri);
        hero.addView(dateRow);

        TextView lbl = Ui.text(this, "SIRADAKİ VAKİT", 11, Ui.MUTED, true);
        lbl.setLetterSpacing(0.12f);
        lbl.setGravity(Gravity.CENTER);
        hero.addView(lbl, Ui.matchLp(this, 0, 14, 0, 0));

        LinearLayout nameRow = Ui.row(this);
        nameRow.setGravity(Gravity.CENTER);
        tvNextName = Ui.text(this, "", 34, Ui.TEXT, true);
        tvNextTime = Ui.text(this, "", 34, Ui.AMBER, true);
        nameRow.addView(tvNextName, Ui.wrapLp(this, 0, 0, 12, 0));
        nameRow.addView(tvNextTime);
        hero.addView(nameRow, Ui.matchLp(this, 0, 2, 0, 0));

        LinearLayout pill = Ui.row(this);
        pill.setGravity(Gravity.CENTER);
        pill.setBackground(Ui.shape(this, Color.WHITE, 26, Color.parseColor("#BBF7D0"), 1));
        pill.setPadding(Ui.dp(this, 18), Ui.dp(this, 8), Ui.dp(this, 18), Ui.dp(this, 8));
        pill.addView(Ui.icon(this, "hourglass", Ui.AMBER, 18), Ui.lp(this, Ui.dp(this, 18), Ui.dp(this, 18), 0, 0, 8, 0));
        tvCountdown = Ui.text(this, "", 22, Ui.TEXT, true);
        pill.addView(tvCountdown);
        pill.addView(Ui.text(this, "  kaldı", 12, Ui.MUTED, false));
        LinearLayout.LayoutParams pillLp = Ui.wrapLp(this, 0, 10, 0, 0);
        pillLp.gravity = Gravity.CENTER_HORIZONTAL;
        hero.addView(pill, pillLp);

        bar = new Ui.Bar(this, Color.parseColor("#D1FAE5"), Ui.GREEN);
        hero.addView(bar, Ui.lp(this, ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 6), 0, 16, 0, 0));
        tvNow = Ui.text(this, "", 11, Ui.MUTED, false);
        tvNow.setGravity(Gravity.CENTER);
        hero.addView(tvNow, Ui.matchLp(this, 0, 8, 0, 0));
        tvSilent = Ui.text(this, "", 12, Ui.GREEN, true);
        tvSilent.setGravity(Gravity.CENTER);
        tvSilent.setVisibility(View.GONE);
        hero.addView(tvSilent, Ui.matchLp(this, 0, 4, 0, 0));

        btnStart = Ui.button(this, "bell", "", Ui.GREEN, Color.WHITE, 0);
        btnStart.setOnClickListener(v -> toggleManual());
        hero.addView(btnStart, Ui.matchLp(this, 0, 14, 0, 0));
        root.addView(hero, Ui.matchLp(this, 0, 10, 0, 0));

        // Otomatik EzanPause
        LinearLayout auto = Ui.card(this);
        LinearLayout autoRow = Ui.row(this);
        FrameLayout autoIcon = Ui.circleIcon(this, "refresh", Ui.GREEN, Ui.MINT, 0, 44, 24);
        autoIcon.setClickable(false);
        autoRow.addView(autoIcon, Ui.lp(this, Ui.dp(this, 44), Ui.dp(this, 44), 0, 0, 12, 0));
        LinearLayout autoTitles = Ui.column(this);
        autoTitles.addView(Ui.text(this, "Otomatik EzanPause", 16, Ui.TEXT, true));
        tvAutoSub = Ui.text(this, "", 11, Ui.GREEN_MID, true);
        autoTitles.addView(tvAutoSub);
        autoRow.addView(autoTitles, Ui.weightLp(this, 1f, 0, 0, 8, 0));
        swAuto = new Switch(this);
        Ui.styleSwitch(swAuto);
        swAuto.setOnCheckedChangeListener((b, checked) -> {
            if (binding) return;
            s = Settings.load(this);
            s.enabled = checked;
            s.save(this);
            Profiles.syncActive(this);
            Scheduler.tick(this);
            refresh();
        });
        autoRow.addView(swAuto);
        auto.addView(autoRow);
        tvAutoDesc = Ui.text(this, "", 12, Ui.MUTED, false);
        tvAutoDesc.setLineSpacing(0, 1.15f);
        auto.addView(tvAutoDesc, Ui.matchLp(this, 0, 10, 0, 0));

        LinearLayout btns = Ui.row(this);
        btnPerm = Ui.button(this, "shield", "İzinleri Ver", Ui.CARD, Ui.TEXT, Color.parseColor("#CBD5E1"));
        btnPerm.icon.setImageDrawable(new Ic("shield", Ui.AMBER_LINE));
        btnPerm.setOnClickListener(v -> {
            if (requestNextMissingPermission()) {
                Toast.makeText(this, "Tüm izinler tamam", Toast.LENGTH_SHORT).show();
            }
        });
        Ui.Btn btnTest = Ui.button(this, "play", "Sessizi Test Et", Ui.AMBER_BG, Ui.AMBER, 0);
        btnTest.setOnClickListener(v -> startTest());
        btns.addView(btnPerm, Ui.weightLp(this, 1f, 0, 0, 6, 0));
        btns.addView(btnTest, Ui.weightLp(this, 1f, 6, 0, 0, 0));
        auto.addView(btns, Ui.matchLp(this, 0, 14, 0, 0));
        root.addView(auto, Ui.matchLp(this, 0, 14, 0, 0));

        // Günlük vakitler
        TextView head = Ui.text(this, "GÜNLÜK VAKİTLER", 12, Ui.MUTED, true);
        head.setLetterSpacing(0.1f);
        root.addView(head, Ui.matchLp(this, 4, 22, 0, 8));

        for (int r = 0; r < 3; r++) {
            LinearLayout line = Ui.row(this);
            line.setBaselineAligned(false);
            for (int k = 0; k < 2; k++) {
                int idx = r * 2 + k;
                line.addView(prayerCard(idx), Ui.weightLp(this, 1f, k == 0 ? 0 : 5, 0, k == 0 ? 5 : 0, 0));
            }
            root.addView(line, Ui.matchLp(this, 0, 5, 0, 5));
        }

        LinearLayout more = Ui.row(this);
        Ui.Btn bCuma = Ui.button(this, null, "Cuma namazı", Ui.CARD, Ui.TEXT, Ui.LINE);
        bCuma.setOnClickListener(v -> openGuide("cuma"));
        Ui.Btn bDua = Ui.button(this, "book", "Dualar ve sûreler", Ui.CARD, Ui.TEXT, Ui.LINE);
        bDua.setOnClickListener(v -> openGuide("dualar"));
        more.addView(bCuma, Ui.weightLp(this, 1f, 0, 0, 5, 0));
        more.addView(bDua, Ui.weightLp(this, 1.3f, 5, 0, 0, 0));
        root.addView(more, Ui.matchLp(this, 0, 8, 0, 0));

        // Son kayıtlar
        LinearLayout log = Ui.card(this);
        log.addView(Ui.text(this, "Son sessizlikler", 15, Ui.TEXT, true));
        tvEvents = Ui.text(this, "", 12, Ui.MUTED, false);
        tvEvents.setLineSpacing(0, 1.2f);
        log.addView(tvEvents, Ui.matchLp(this, 0, 6, 0, 0));
        root.addView(log, Ui.matchLp(this, 0, 16, 0, 0));
    }

    private LinearLayout prayerCard(final int idx) {
        LinearLayout c = Ui.column(this);
        c.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 14));
        c.setClickable(true);
        c.setFocusable(true);
        c.setOnClickListener(v -> openGuide(KEYS[idx]));

        LinearLayout top = Ui.row(this);
        ImageView ic = Ui.icon(this, ICONS[idx], Color.parseColor("#475569"), 24);
        cardIcons[idx] = ic;
        top.addView(ic, Ui.lp(this, Ui.dp(this, 24), Ui.dp(this, 24), 0, 0, 0, 0));
        top.addView(new View(this), Ui.weightLp(this, 1f, 0, 0, 0, 0));
        TextView badge = Ui.text(this, "", 9, Color.WHITE, true);
        badge.setPadding(Ui.dp(this, 7), Ui.dp(this, 2), Ui.dp(this, 7), Ui.dp(this, 2));
        badge.setVisibility(View.GONE);
        cardBadges[idx] = badge;
        top.addView(badge);
        c.addView(top);

        c.addView(Ui.text(this, NAMES[idx], 17, Ui.TEXT, true), Ui.matchLp(this, 0, 10, 0, 0));
        TextView time = Ui.text(this, "--:--", 26, Ui.TEXT, true);
        cardTimes[idx] = time;
        c.addView(time);
        c.addView(Ui.text(this, SUBS[idx], 11, Ui.MUTED, false), Ui.matchLp(this, 0, 2, 0, 0));
        cards[idx] = c;
        return c;
    }

    private void openGuide(String key) {
        startActivity(new Intent(this, GuideActivity.class).putExtra(GuideActivity.EXTRA_KEY, key));
    }

    // ------------------------------------------------------------------ elle sessizlik

    private void toggleManual() {
        Scheduler.Snapshot snap = Scheduler.snapshot(this);
        long now = System.currentTimeMillis();
        if (snap.active != null) {
            boolean manual = "Elle".equals(snap.active.name) || "Deneme".equals(snap.active.name);
            if (manual) {
                Scheduler.cancelManualWindow(this);
                Toast.makeText(this, "Sessizlik bitirildi", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Ezan sessizliği sürüyor, süre bitince ses açılır", Toast.LENGTH_SHORT).show();
            }
        } else {
            Settings cur = Settings.load(this);
            Scheduler.addManualWindow(this, now + 300, now + cur.durationSec * 1000L, "Elle");
            Toast.makeText(this, Ui.humanSec(cur.durationSec) + " sessizlik başladı", Toast.LENGTH_SHORT).show();
        }
        refresh();
    }

    // ------------------------------------------------------------------ durum

    private void ensureEvents(PrayerTimes.City city, long now) {
        LocalDate today = Instant.ofEpochMilli(now).atZone(city.zone).toLocalDate();
        if (today.equals(evsDate) && city.name.equals(evsCity)) return;
        evs.clear();
        for (int d = -1; d <= 1; d++) {
            PrayerTimes.Day day = PrayerTimes.compute(city, today.plusDays(d));
            long[] t = {day.imsak, day.gunes, day.ogle, day.ikindi, day.aksam, day.yatsi};
            for (int i = 0; i < t.length; i++) evs.add(new Ev(i, t[i]));
            if (d == 0) todayTimes = t;
        }
        evsDate = today;
        evsCity = city.name;
    }

    private void refresh() {
        long now = System.currentTimeMillis();
        PrayerTimes.City city = PrayerTimes.find(s.city);
        DateTimeFormatter hm = DateTimeFormatter.ofPattern("HH:mm").withZone(city.zone);
        ensureEvents(city, now);

        tvCity.setText(city.name);
        tvDate.setText(Hijri.gregorian(evsDate));
        tvHijri.setText(Hijri.hijri(evsDate));

        Ev cur = null;
        Ev nxt = null;
        for (Ev e : evs) {
            if (e.t <= now) {
                cur = e;
            } else {
                nxt = e;
                break;
            }
        }
        if (nxt != null) {
            tvNextName.setText(NAMES[nxt.idx]);
            tvNextTime.setText(hm.format(Instant.ofEpochMilli(nxt.t)));
            tvCountdown.setText(Ui.hms(nxt.t - now));
            if (cur != null) {
                bar.setFraction((now - cur.t) / (float) Math.max(1, nxt.t - cur.t));
                tvNow.setText("Şu anki vakit: " + NAMES[cur.idx] + " (" + hm.format(Instant.ofEpochMilli(cur.t)) + ")");
            }
        }

        for (int i = 0; i < 6; i++) {
            cardTimes[i].setText(hm.format(Instant.ofEpochMilli(todayTimes[i])));
            int st = (cur != null && cur.idx == i) ? 2 : (nxt != null && nxt.idx == i) ? 1 : 0;
            if (cardState[i] != st) {
                cardState[i] = st;
                applyCardState(i, st);
            }
        }

        Scheduler.Snapshot snap = Scheduler.snapshot(this);
        binding = true;
        swAuto.setChecked(s.enabled);
        binding = false;
        tvAutoSub.setText(s.enabled ? "Namazlarda otomatik sessiz devrede" : "Kapalı");
        tvAutoSub.setTextColor(s.enabled ? Ui.GREEN_MID : Ui.MUTED);
        tvAutoDesc.setText("Namaz vaktinde medya sesi otomatik kapatılır, " + Ui.humanSec(s.durationSec)
                + " sonra ses normale döner." + (s.offsetSec > 0 ? " Ezandan " + Ui.humanSec(s.offsetSec) + " önce başlar." : ""));

        if (snap.active != null) {
            tvSilent.setVisibility(View.VISIBLE);
            tvSilent.setText("Şu an sessizde: " + snap.active.name + " · kalan " + Ui.hms(snap.active.end - now));
            boolean manual = "Elle".equals(snap.active.name) || "Deneme".equals(snap.active.name);
            btnStart.label.setText(manual ? "Sessizliği Bitir" : "Ezan sessizliği sürüyor");
        } else {
            tvSilent.setVisibility(View.GONE);
            btnStart.label.setText("EzanPause Başlat (" + Ui.humanSec(s.durationSec) + " sessiz)");
        }

        boolean permsOk = Scheduler.canScheduleExact(this)
                && getSystemService(android.app.NotificationManager.class).areNotificationsEnabled();
        btnPerm.label.setText(permsOk ? "İzinler Tamam" : "İzinleri Ver");

        List<String> ev = EventLog.recent(this, 5, city.zone);
        tvEvents.setText(ev.isEmpty() ? "Henüz kayıt yok." : String.join("\n", ev));
    }

    private void applyCardState(int i, int st) {
        int fill = Ui.CARD;
        int stroke = Ui.LINE;
        int iconColor = Color.parseColor("#475569");
        String badge = null;
        int badgeBg = 0;
        if (st == 2) {
            fill = Color.parseColor("#ECFDF5");
            stroke = Ui.GREEN;
            iconColor = Ui.GREEN;
            badge = "VAKİTTE";
            badgeBg = Ui.GREEN;
        } else if (st == 1) {
            fill = Color.parseColor("#FFFBEB");
            stroke = Ui.AMBER_LINE;
            iconColor = Ui.AMBER_LINE;
            badge = "SIRADAKİ";
            badgeBg = Ui.AMBER_LINE;
        }
        cards[i].setBackground(Ui.ripple(this, fill, 18, stroke, st == 0 ? 1 : 2));
        cardIcons[i].setImageDrawable(new Ic(ICONS[i], iconColor));
        if (badge == null) {
            cardBadges[i].setVisibility(View.GONE);
        } else {
            cardBadges[i].setVisibility(View.VISIBLE);
            cardBadges[i].setText(badge);
            cardBadges[i].setBackground(Ui.shape(this, badgeBg, 10, 0, 0));
        }
    }
}
