package app.ezanpause;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;

import java.util.Collections;
import java.util.List;

/** Google Play abonelik (satın alma) işlemleri. Ürün: ezanpause_pro; temel planlar: aylik, yillik. */
final class Billing {
    static final String PRODUCT = "ezanpause_pro";
    static final String BASE_MONTHLY = "aylik";
    static final String BASE_YEARLY = "yillik";
    private static final String PREFS = "ezanpause_play";
    private static final long GRACE_MS = 7L * 24 * 3600_000L;

    interface Listener {
        void onPrices(String monthly, String yearly);   // null = bulunamadı

        void onStatus(boolean active, String message);
    }

    private final Context ctx;
    private final Listener listener;
    private BillingClient client;
    private ProductDetails details;

    Billing(Context c, Listener l) {
        this.ctx = c.getApplicationContext();
        this.listener = l;
    }

    // ---------------------------------------------------------------- durum (internetsiz)

    /** Google Play aboneliği etkin mi? (son bilinen duruma bakar) */
    static boolean active(Context c) {
        SharedPreferences s = c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!s.getBoolean("active", false)) return false;
        return System.currentTimeMillis() - s.getLong("checked", 0) < GRACE_MS;
    }

    private static void save(Context c, boolean on) {
        c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean("active", on).putLong("checked", System.currentTimeMillis()).apply();
        try {
            Scheduler.tick(c);
        } catch (Throwable ignored) {
        }
    }

    // ---------------------------------------------------------------- bağlantı

    private void connect(final Runnable ready) {
        if (client != null && client.isReady()) {
            ready.run();
            return;
        }
        client = BillingClient.newBuilder(ctx)
                .setListener(makeListener())
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .build();
        client.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult r) {
                if (r.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    ready.run();
                } else {
                    listener.onStatus(false, "Google Play'e bağlanılamadı.");
                    listener.onPrices(null, null);
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
            }
        });
    }

    void close() {
        try {
            if (client != null) client.endConnection();
        } catch (Throwable ignored) {
        }
        client = null;
    }

    /** Fiyatları ve mevcut aboneliği Google Play'den okur. */
    void load() {
        connect(() -> {
            queryOwned();
            QueryProductDetailsParams.Product prod = QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(PRODUCT).setProductType(BillingClient.ProductType.SUBS).build();
            client.queryProductDetailsAsync(
                    QueryProductDetailsParams.newBuilder().setProductList(Collections.singletonList(prod)).build(),
                    (res, list) -> {
                        if (res.getResponseCode() != BillingClient.BillingResponseCode.OK || list == null || list.isEmpty()) {
                            listener.onPrices(null, null);
                            return;
                        }
                        details = list.get(0);
                        ProductDetails.SubscriptionOfferDetails m = pick(BASE_MONTHLY);
                        ProductDetails.SubscriptionOfferDetails y = pick(BASE_YEARLY);
                        listener.onPrices(m == null ? null : priceText(m), y == null ? null : priceText(y));
                    });
        });
    }

    /** Önce ücretsiz deneme teklifi, yoksa normal teklif. */
    private ProductDetails.SubscriptionOfferDetails pick(String basePlan) {
        if (details == null || details.getSubscriptionOfferDetails() == null) return null;
        ProductDetails.SubscriptionOfferDetails plain = null;
        for (ProductDetails.SubscriptionOfferDetails o : details.getSubscriptionOfferDetails()) {
            if (!basePlan.equals(o.getBasePlanId())) continue;
            if (o.getOfferId() != null && hasTrial(o)) return o;
            if (o.getOfferId() == null) plain = o;
        }
        return plain;
    }

    private static boolean hasTrial(ProductDetails.SubscriptionOfferDetails o) {
        List<ProductDetails.PricingPhase> ph = o.getPricingPhases().getPricingPhaseList();
        return ph.size() > 1 && ph.get(0).getPriceAmountMicros() == 0;
    }

    private static String priceText(ProductDetails.SubscriptionOfferDetails o) {
        List<ProductDetails.PricingPhase> ph = o.getPricingPhases().getPricingPhaseList();
        String price = ph.get(ph.size() - 1).getFormattedPrice();
        return hasTrial(o) ? "7 gün ücretsiz, sonra " + price : price;
    }

    // ---------------------------------------------------------------- satın alma

    void buy(Activity a, String basePlan) {
        if (client == null || !client.isReady() || details == null) {
            listener.onStatus(false, "Fiyatlar henüz yüklenmedi. Biraz bekleyip tekrar deneyin.");
            return;
        }
        ProductDetails.SubscriptionOfferDetails o = pick(basePlan);
        if (o == null) {
            listener.onStatus(false, "Bu plan şu an satın alınamıyor.");
            return;
        }
        BillingFlowParams.ProductDetailsParams pd = BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(details).setOfferToken(o.getOfferToken()).build();
        BillingFlowParams params = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(Collections.singletonList(pd)).build();
        client.launchBillingFlow(a, params);
    }

    private PurchasesUpdatedListener makeListener() {
        return (res, purchases) -> {
        int code = res.getResponseCode();
        if (code == BillingClient.BillingResponseCode.OK && purchases != null) {
            handle(purchases);
        } else if (code == BillingClient.BillingResponseCode.USER_CANCELED) {
            listener.onStatus(Billing.active(ctx), "Satın alma iptal edildi.");
        } else {
            listener.onStatus(Billing.active(ctx), "Satın alma tamamlanamadı.");
        }
        };
    }

    private void queryOwned() {
        client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build(),
                (res, list) -> {
                    if (res.getResponseCode() == BillingClient.BillingResponseCode.OK && list != null) handle(list);
                });
    }

    private void handle(List<Purchase> list) {
        boolean on = false;
        for (Purchase p : list) {
            if (!p.getProducts().contains(PRODUCT)) continue;
            if (p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                on = true;
                if (!p.isAcknowledged() && client != null && client.isReady()) {
                    client.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.getPurchaseToken()).build(), r -> {
                    });
                }
            }
        }
        save(ctx, on);
        listener.onStatus(on, on ? "Pro etkin. Teşekkürler!" : "");
    }

    /** Ana ekran açılırken sessizce abonelik durumunu yeniler. */
    static void refreshSilently(final Context c) {
        final Billing[] holder = new Billing[1];
        holder[0] = new Billing(c, new Listener() {
            @Override
            public void onPrices(String monthly, String yearly) {
            }

            @Override
            public void onStatus(boolean active, String message) {
            }
        });
        holder[0].connect(() -> {
            holder[0].queryOwned();
        });
    }
}
