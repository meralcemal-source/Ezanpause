package app.ezanpause;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/** Harici dosya gerektirmeyen, kodla çizilen basit simgeler (24x24 ızgarada). */
final class Ic extends Drawable {
    private final String name;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);

    Ic(String name, int color) {
        this.name = name;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(color);
        line.setStyle(Paint.Style.STROKE);
        line.setColor(color);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStrokeWidth(2f);
    }

    @Override
    public void draw(Canvas c) {
        android.graphics.Rect b = getBounds();
        if (b.width() <= 0 || b.height() <= 0) return;
        c.save();
        c.translate(b.left, b.top);
        c.scale(b.width() / 24f, b.height() / 24f);
        paint(c);
        c.restore();
    }

    private void paint(Canvas c) {
        switch (name) {
            case "star": {
                Path p = new Path();
                for (int i = 0; i < 10; i++) {
                    double ang = -Math.PI / 2 + i * Math.PI / 5;
                    float r = (i % 2 == 0) ? 10f : 4.3f;
                    float x = (float) (12 + r * Math.cos(ang));
                    float y = (float) (12.8 + r * Math.sin(ang));
                    if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
                }
                p.close();
                c.drawPath(p, fill);
                break;
            }
            case "gear": {
                for (int i = 0; i < 8; i++) {
                    c.save();
                    c.rotate(45f * i, 12, 12);
                    c.drawRoundRect(new RectF(10.2f, 2f, 13.8f, 7f), 1f, 1f, fill);
                    c.restore();
                }
                line.setStrokeWidth(3f);
                c.drawCircle(12, 12, 6f, line);
                line.setStrokeWidth(2f);
                break;
            }
            case "book": {
                Path l = new Path();
                l.moveTo(3, 5.5f); l.lineTo(11, 7.5f); l.lineTo(11, 20f); l.lineTo(3, 18f); l.close();
                Path r = new Path();
                r.moveTo(21, 5.5f); r.lineTo(13, 7.5f); r.lineTo(13, 20f); r.lineTo(21, 18f); r.close();
                c.drawPath(l, fill);
                c.drawPath(r, fill);
                break;
            }
            case "speaker": {
                Path p = new Path();
                p.moveTo(3, 9); p.lineTo(7, 9); p.lineTo(12, 4.5f); p.lineTo(12, 19.5f); p.lineTo(7, 15); p.lineTo(3, 15); p.close();
                c.drawPath(p, fill);
                c.drawArc(new RectF(8, 8, 16, 16), -50, 100, false, line);
                c.drawArc(new RectF(5.5f, 5.5f, 18.5f, 18.5f), -50, 100, false, line);
                break;
            }
            case "pin": {
                Path a = new Path();
                a.addCircle(12, 9.5f, 6f, Path.Direction.CW);
                Path t = new Path();
                t.moveTo(6.6f, 12.5f); t.lineTo(12, 21.5f); t.lineTo(17.4f, 12.5f); t.close();
                a.op(t, Path.Op.UNION);
                Path hole = new Path();
                hole.addCircle(12, 9.5f, 2.4f, Path.Direction.CW);
                a.op(hole, Path.Op.DIFFERENCE);
                c.drawPath(a, fill);
                break;
            }
            case "moon": {
                Path a = new Path();
                a.addCircle(12, 12, 8.5f, Path.Direction.CW);
                Path b = new Path();
                b.addCircle(16.5f, 9, 7.2f, Path.Direction.CW);
                a.op(b, Path.Op.DIFFERENCE);
                c.drawPath(a, fill);
                break;
            }
            case "sun": {
                c.drawCircle(12, 12, 4.6f, fill);
                for (int i = 0; i < 8; i++) {
                    double ang = i * Math.PI / 4;
                    c.drawLine((float) (12 + 7.6 * Math.cos(ang)), (float) (12 + 7.6 * Math.sin(ang)),
                            (float) (12 + 10.2 * Math.cos(ang)), (float) (12 + 10.2 * Math.sin(ang)), line);
                }
                break;
            }
            case "sunset": {
                c.drawArc(new RectF(6.5f, 9.5f, 17.5f, 20.5f), 180, 180, true, fill);
                c.drawLine(2.5f, 20.5f, 21.5f, 20.5f, line);
                for (int i = 0; i < 5; i++) {
                    double ang = Math.PI + (i + 0.5) * Math.PI / 5;
                    c.drawLine((float) (12 + 8.2 * Math.cos(ang)), (float) (15 + 8.2 * Math.sin(ang)),
                            (float) (12 + 10.4 * Math.cos(ang)), (float) (15 + 10.4 * Math.sin(ang)), line);
                }
                break;
            }
            case "cloud": {
                c.drawCircle(8, 14, 4.5f, fill);
                c.drawCircle(13, 11.5f, 5.5f, fill);
                c.drawCircle(17.5f, 14.5f, 4f, fill);
                c.drawRoundRect(new RectF(8, 13, 17.5f, 18.5f), 2f, 2f, fill);
                break;
            }
            case "bell": {
                Path p = new Path();
                p.moveTo(6, 17); p.lineTo(6, 11);
                p.cubicTo(6, 7.5f, 8.7f, 5.8f, 12, 5.8f);
                p.cubicTo(15.3f, 5.8f, 18, 7.5f, 18, 11);
                p.lineTo(18, 17); p.lineTo(20, 19); p.lineTo(4, 19); p.close();
                c.drawPath(p, fill);
                c.drawCircle(12, 4.2f, 1.4f, fill);
                c.drawCircle(12, 21f, 1.7f, fill);
                break;
            }
            case "person": {
                c.drawCircle(12, 8, 4.2f, fill);
                Path p = new Path();
                p.moveTo(4, 21); p.cubicTo(4, 16.5f, 8, 14, 12, 14); p.cubicTo(16, 14, 20, 16.5f, 20, 21); p.close();
                c.drawPath(p, fill);
                break;
            }
            case "check": {
                line.setStrokeWidth(2.8f);
                Path p = new Path();
                p.moveTo(5, 12.5f); p.lineTo(10, 17.5f); p.lineTo(19, 7);
                c.drawPath(p, line);
                line.setStrokeWidth(2f);
                break;
            }
            case "hourglass": {
                Path p = new Path();
                p.moveTo(7, 3.5f); p.lineTo(17, 3.5f); p.lineTo(12, 12); p.close();
                p.moveTo(7, 20.5f); p.lineTo(17, 20.5f); p.lineTo(12, 12); p.close();
                c.drawPath(p, fill);
                break;
            }
            case "shield": {
                Path p = new Path();
                p.moveTo(12, 3); p.lineTo(20, 6); p.lineTo(20, 12);
                p.cubicTo(20, 17, 16, 20, 12, 21.5f);
                p.cubicTo(8, 20, 4, 17, 4, 12);
                p.lineTo(4, 6); p.close();
                c.drawPath(p, fill);
                break;
            }
            case "play": {
                Path p = new Path();
                p.moveTo(8, 5); p.lineTo(8, 19); p.lineTo(19, 12); p.close();
                c.drawPath(p, fill);
                break;
            }
            case "refresh": {
                c.drawArc(new RectF(5, 5, 19, 19), 60, 270, false, line);
                Path p = new Path();
                p.moveTo(19.7f, 11.3f); p.lineTo(20.7f, 7f); p.lineTo(15.5f, 10f); p.close();
                c.drawPath(p, fill);
                break;
            }
            case "plus": {
                c.drawLine(12, 5, 12, 19, line);
                c.drawLine(5, 12, 19, 12, line);
                break;
            }
            case "chevron_left": {
                Path p = new Path();
                p.moveTo(15, 5); p.lineTo(8, 12); p.lineTo(15, 19);
                c.drawPath(p, line);
                break;
            }
            case "chevron_right": {
                Path p = new Path();
                p.moveTo(9, 5); p.lineTo(16, 12); p.lineTo(9, 19);
                c.drawPath(p, line);
                break;
            }
            case "circle": {
                line.setStrokeWidth(2f);
                c.drawCircle(12, 12, 8f, line);
                break;
            }
            default:
                c.drawCircle(12, 12, 6, fill);
        }
    }

    @Override
    public void setAlpha(int alpha) {
        fill.setAlpha(alpha);
        line.setAlpha(alpha);
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {
        fill.setColorFilter(colorFilter);
        line.setColorFilter(colorFilter);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
