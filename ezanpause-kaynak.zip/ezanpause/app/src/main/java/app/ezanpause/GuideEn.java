package app.ezanpause;

import java.util.HashMap;
import java.util.Map;

/** Namaz rehberi ve dua metinlerinin İngilizce karşılıkları (tam metin eşleşmesi). */
final class GuideEn {
    static final Map<String, String> M = new HashMap<>();
    static {
        M.put("İmsak / Sabah namazı",
                "Fajr (Dawn) prayer");
        M.put("Vakit: Fecr-i sâdık (tan yerinin ağarması) ile başlar, güneş doğmadan önce biter.",
                "Time: Begins with true dawn (fajr al-sadiq, when the horizon turns light) and ends before sunrise.");
        M.put("Güneş doğarken kerahat vakti başlar (yaklaşık 45 dk sürer) ve bu sırada namaz kılınmaz; bu yüzden sabah namazı güneş doğmadan kılınmalıdır. Sabahın sünneti, sünnetlerin en kuvvetlisidir.",
                "The time of disliked prayer (karaha) begins at sunrise (lasting about 45 min) and no prayer is performed then; therefore the Fajr prayer should be performed before sunrise. The sunnah of Fajr is the strongest of all sunnahs.");
        M.put("Sabahın sünneti",
                "Sunnah of Fajr");
        M.put("Müekkede sünnet",
                "Emphasized sunnah (muakkad)");
        M.put("1. rekât: Niyet edip \"Allâhü ekber\" diyerek tekbir alınır, eller bağlanır. Sübhâneke okunur, Euzü-Besmele çekilir, Fâtiha okunur, ardından zamm-ı sûre (örn. Kevser, İhlâs, Fîl) okunur. Rükû, kavme, iki secde yapılır.",
                "Rakat 1: Make the intention and raise the opening takbir (\"Allahu akbar\"), folding the hands. Recite Subhanaka, the Euzu-Basmala, Al-Fatiha, then an additional surah (e.g. Kawthar, Ikhlas, Fil). Bow (ruku), stand up (qawma) and perform two prostrations.");
        M.put("2. rekât: Besmele ile Fâtiha, zamm-ı sûre okunur (Sübhâneke okunmaz). Rükû ve iki secdeden sonra son oturuşta Ettehiyyâtü, Allâhümme salli, Allâhümme bârik, Rabbenâ duaları okunur. Önce sağa, sonra sola \"Esselâmü aleyküm ve rahmetullâh\" diyerek selam verilir.",
                "Rakat 2: Recite Basmala, Al-Fatiha and an additional surah (Subhanaka is not repeated). After the bowing and two prostrations, in the final sitting recite Tahiyyat, Allahumma salli, Allahumma barik and the Rabbana supplications. Then give salaam to the right and to the left, saying \"Assalamu alaykum wa rahmatullah\".");
        M.put("Sabahın farzı",
                "Fard of Fajr");
        M.put("Farz",
                "Fard (obligatory)");
        M.put("Güneş doğuşu",
                "Sunrise");
        M.put("Güneşin doğuşu sabah namazı vaktinin sonudur; bu andan itibaren sabah farzı kaza olur.",
                "Sunrise marks the end of the Fajr time; from this moment the Fajr fard becomes a missed (qada) prayer.");
        M.put("Güneş doğarken ve doğuşundan yaklaşık 45 dk sonrasına kadar (güneş yükselene dek) kerahat vakti sürer; bu sürede namaz kılınmaz. Kerahat vakitleri üçtür: güneşin doğuşu, tam tepede olduğu an (zeval) ve batışa yakın, sararıp gözün alabildiği zaman. Kerahat vakti çıkınca isteyen kuşluk (duha) namazı kılabilir; kuşluk 2 ile 12 rekât arası nafile bir namazdır.",
                "The disliked time lasts at sunrise and until about 45 min after it (until the sun has risen); no prayer is performed in this period. There are three disliked times: sunrise, the moment the sun is at its peak (zawal), and near sunset when the sun turns yellow and the eye can look at it. Once the disliked time is over, one may perform the Duha (forenoon) prayer, a voluntary prayer of 2 to 12 rakat.");
        M.put("Öğle namazı",
                "Dhuhr (Noon) prayer");
        M.put("Vakit: Güneş tepe noktasını (zeval) geçince başlar, ikindi vaktine kadar sürür.",
                "Time: Begins when the sun passes its peak (zawal) and lasts until the Asr time.");
        M.put("Vakit tam zeval anındayken (güneş tepedeyken) namaz kılınmaz; zeval geçince başlar.",
                "No prayer is performed exactly at the moment of zawal (when the sun is at its peak); it begins once zawal has passed.");
        M.put("Öğlenin ilk sünneti",
                "First sunnah of Dhuhr");
        M.put("1. rekât: Sübhâneke, Euzü-Besmele, Fâtiha, zamm-ı sûre; rükû, iki secde.",
                "Rakat 1: Subhanaka, Euzu-Basmala, Al-Fatiha, an additional surah; bowing, two prostrations.");
        M.put("2. rekât: Besmele, Fâtiha, zamm-ı sûre; rükû, iki secde. İlk oturuşta yalnız Ettehiyyâtü okunur, kalkılır.",
                "Rakat 2: Basmala, Al-Fatiha, an additional surah; bowing, two prostrations. In the first sitting only Tahiyyat is recited, then stand up.");
        M.put("3. rekât: Besmele, Fâtiha, zamm-ı sûre (sünnette 3. ve 4. rekâtta da sûre okunur); rükû, iki secde.",
                "Rakat 3: Basmala, Al-Fatiha, an additional surah (in sunnah prayers a surah is also recited in the 3rd and 4th rakat); bowing, two prostrations.");
        M.put("4. rekât: Besmele, Fâtiha, zamm-ı sûre; rükû, iki secde. Son oturuşta Ettehiyyâtü, Allâhümme salli, Allâhümme bârik, Rabbenâ okunur ve selam verilir.",
                "Rakat 4: Basmala, Al-Fatiha, an additional surah; bowing, two prostrations. In the final sitting recite Tahiyyat, Allahumma salli, Allahumma barik, Rabbana, and give salaam.");
        M.put("Öğlenin farzı",
                "Fard of Dhuhr");
        M.put("Namaza kalkmadan önce kamet getirilir. Farz niyetiyle tekbir alınır.",
                "The iqama is called before standing for the prayer. Raise the takbir with the intention of the fard.");
        M.put("3. rekât: Yalnız Fâtiha okunur, sûre OKUNMAZ (farzın 3. ve 4. rekâtında zamm-ı sûre yoktur); rükû, iki secde.",
                "Rakat 3: Only Al-Fatiha is recited, NO surah (there is no additional surah in the 3rd and 4th rakat of a fard); bowing, two prostrations.");
        M.put("4. rekât: Yalnız Fâtiha; rükû, iki secde. Son oturuşta Ettehiyyâtü, Allâhümme salli, Allâhümme bârik, Rabbenâ okunur ve selam verilir. Ardından tesbihat yapılır.",
                "Rakat 4: Only Al-Fatiha; bowing, two prostrations. In the final sitting recite Tahiyyat, Allahumma salli, Allahumma barik, Rabbana, and give salaam. Then the tasbihat is performed.");
        M.put("Öğlenin son sünneti",
                "Last sunnah of Dhuhr");
        M.put("İkindi namazı",
                "Asr (Afternoon) prayer");
        M.put("Vakit: Öğle vakti çıkınca başlar, güneş batıncaya kadar sürür.",
                "Time: Begins when the Dhuhr time ends and lasts until sunset.");
        M.put("Güneş sararıp batmaya yaklaşınca (kerahat vakti) o günün ikindi farzı dışında nafile namaz kılınmaz.",
                "When the sun turns yellow and approaches sunset (disliked time), no voluntary prayer is performed except the Asr fard of that day.");
        M.put("İkindinin sünneti",
                "Sunnah of Asr");
        M.put("Gayri müekkede sünnet",
                "Non-emphasized sunnah (ghayr muakkad)");
        M.put("2. rekât: Besmele, Fâtiha, zamm-ı sûre; rükû, iki secde. İlk oturuşta Ettehiyyâtü, Allâhümme salli ve Allâhümme bârik okunur, kalkılır.",
                "Rakat 2: Basmala, Al-Fatiha, an additional surah; bowing, two prostrations. In the first sitting recite Tahiyyat, Allahumma salli and Allahumma barik, then stand up.");
        M.put("3. rekât: Bu rekâtta tekrar Sübhâneke okunur (gayri müekkede sünnete özgü), Euzü-Besmele, Fâtiha ve zamm-ı sûre; rükû, iki secde.",
                "Rakat 3: Subhanaka is recited again in this rakat (specific to non-emphasized sunnah), then Euzu-Basmala, Al-Fatiha and an additional surah; bowing, two prostrations.");
        M.put("İkindinin farzı",
                "Fard of Asr");
        M.put("Akşam namazı",
                "Maghrib (Sunset) prayer");
        M.put("Vakit: Güneşin batışıyla başlar, batı ufkundaki kızıllık (şafak) kayboluncaya kadar sürer.",
                "Time: Begins at sunset and lasts until the redness (twilight) on the western horizon disappears.");
        M.put("Akşam farzı 3 rekâttır ve gündüz namazlarının vitri sayılır. Vakti kısa olduğu için geciktirilmemesi tavsiye edilir.",
                "The Maghrib fard is 3 rakat and is regarded as the witr of the daytime prayers. Since its time is short, it is advised not to delay it.");
        M.put("Akşamın farzı",
                "Fard of Maghrib");
        M.put("Kamet getirilir, farz niyetiyle tekbir alınır.",
                "The iqama is called and the takbir is raised with the intention of the fard.");
        M.put("3. rekât: Yalnız Fâtiha okunur, sûre okunmaz; rükû, iki secde. Son oturuşta Ettehiyyâtü, Allâhümme salli, Allâhümme bârik, Rabbenâ okunur, selam verilir. Ardından tesbihat yapılır.",
                "Rakat 3: Only Al-Fatiha is recited, no surah; bowing, two prostrations. In the final sitting recite Tahiyyat, Allahumma salli, Allahumma barik, Rabbana, and give salaam. Then the tasbihat is performed.");
        M.put("Akşamın son sünneti",
                "Last sunnah of Maghrib");
        M.put("Yatsı namazı",
                "Isha (Night) prayer");
        M.put("Vakit: Kızıllık kaybolunca (şafağın bitmesiyle) başlar, imsak vaktine (fecr-i sâdık) kadar sürer.",
                "Time: Begins when the redness disappears (end of twilight) and lasts until the Fajr time (true dawn).");
        M.put("Vitir namazı vaciptir; yatsı farzından sonra kılınır. Perşembe günleri yatsıdan önce Selâ okunması yaygın bir uygulamadır.",
                "The Witr prayer is wajib; it is performed after the Isha fard. Reciting the Sala before Isha on Thursdays is a common practice.");
        M.put("Yatsının ilk sünneti",
                "First sunnah of Isha");
        M.put("Yatsının farzı",
                "Fard of Isha");
        M.put("Yatsının son sünneti",
                "Last sunnah of Isha");
        M.put("Vitir namazı",
                "Witr prayer");
        M.put("Vacip",
                "Wajib (necessary)");
        M.put("2. rekât: Besmele, Fâtiha, zamm-ı sûre; rükû, iki secde. İlk oturuşta Ettehiyyâtü okunur (Hanefî'de vitir bir selamla, üç rekât bitişik kılınır), kalkılır.",
                "Rakat 2: Basmala, Al-Fatiha, an additional surah; bowing, two prostrations. In the first sitting only Tahiyyat is recited (in the Hanafi school witr is performed as three rakat in one go with a single salaam), then stand up.");
        M.put("3. rekât: Fâtiha ve zamm-ı sûre okunduktan sonra rükûya gitmeden \"Allâhü ekber\" denilip eller kulaklara kaldırılır ve tekrar bağlanır; Kunut duaları (Allâhümme innâ nestein'ük… ve Allâhümme iyyâke na'büdü…) okunur. Sonra rükû, iki secde, son oturuş ve selam.",
                "Rakat 3: After reciting Al-Fatiha and an additional surah, before bowing say \"Allahu akbar\", raise the hands to the ears and fold them again; recite the Qunut supplications (Allahumma inna nastainuka… and Allahumma iyyaka na'budu…). Then bow, two prostrations, the final sitting and salaam.");
        M.put("Cuma namazı",
                "Friday (Jumu'ah) prayer");
        M.put("Vakit: Öğle vaktinde, cemaatle ve hutbe dinlenerek kılınır.",
                "Time: Performed at the Dhuhr time, in congregation, listening to the sermon (khutbah).");
        M.put("Cuma farzı 2 rekâttır ve cemaatle kılınır. Hutbe okunurken konuşulmaz, namaz kılınmaz. Cumada öğle namazı kılınmaz; cuma farzı onun yerini tutar. Cuma selâsı: Cuma günü ezandan yaklaşık yarım saat–bir saat önce camilerden okunur; kesin bir dakika yoktur, yöreye ve camiye göre değişir (EzanPause'de dakikayı Ayarlar'dan siz belirlersiniz). Perşembe akşamı selâsı ise yatsıdan önce, bazı yörelerde sürdürülen bir gelenektir.",
                "The Friday fard is 2 rakat and is performed in congregation. No one speaks or prays while the sermon is being delivered. The Dhuhr prayer is not performed on Friday; the Friday fard takes its place. Friday Sala: recited from the mosques on Friday about half an hour to one hour before the adhan; there is no exact minute and it varies by region and mosque (in EzanPause you set the minutes in Settings). The Thursday evening Sala, before Isha, is a custom kept in some regions.");
        M.put("Cumanın ilk sünneti",
                "First sunnah of Friday");
        M.put("Cuma farzı (imamla)",
                "Friday fard (with the imam)");
        M.put("Hutbe dinlenir, kamet getirilir. İmama uyma niyetiyle tekbir alınır.",
                "The sermon is listened to and the iqama is called. Raise the takbir with the intention of following the imam.");
        M.put("Cemaatle: Sübhâneke okunur, imam sesli Fâtiha ve sûre okur; cemaat sessizce dinler. Rükû ve secdeler imamla birlikte yapılır. Son oturuşta Ettehiyyâtü, Allâhümme salli, Allâhümme bârik, Rabbenâ okunur; imamla selam verilir.",
                "In congregation: Subhanaka is recited; the imam recites Al-Fatiha and the surah aloud and the congregation listens silently. Bowing and prostrations are performed together with the imam. In the final sitting recite Tahiyyat, Allahumma salli, Allahumma barik, Rabbana; salaam is given with the imam.");
        M.put("Cumanın son sünneti",
                "Last sunnah of Friday");
        M.put("Sübhâneke",
                "Subhanaka");
        M.put("Her namazda ilk rekâtta, tekbirden sonra",
                "In every prayer, in the first rakat, after the takbir");
        M.put("Allahım! Seni her türlü eksiklikten uzak tutar, sana hamdederim. Senin adın mübarektir, şanın yücedir. Senden başka ilah yoktur.",
                "O Allah! I declare You free of every imperfection and praise You. Blessed is Your name, exalted is Your majesty. There is no god but You.");
        M.put("Fâtiha Sûresi",
                "Surah Al-Fatiha");
        M.put("Her rekâtta okunur (Euzü-Besmele ile başlanır)",
                "Recited in every rakat (begin with the Euzu-Basmala)");
        M.put("Rahman ve Rahim Allah'ın adıyla. Hamd, âlemlerin Rabbi Allah'a mahsustur. O, Rahman'dır, Rahim'dir. Din gününün sahibidir. Yalnız sana kulluk eder, yalnız senden yardım dileriz. Bizi doğru yola ilet; kendilerine nimet verdiklerinin yoluna; gazaba uğrayanların ve sapıkların yoluna değil.",
                "In the name of Allah, the Most Merciful, the Most Compassionate. Praise be to Allah, Lord of the worlds. The Most Merciful, the Most Compassionate. Master of the Day of Judgment. You alone we worship, and You alone we ask for help. Guide us to the straight path; the path of those You have blessed, not of those who earned anger, nor of those who went astray.");
        M.put("İhlâs Sûresi (zamm-ı sûre)",
                "Surah Al-Ikhlas (additional surah)");
        M.put("Fâtiha'dan sonra okunabilecek sûrelerden",
                "One of the surahs that can be recited after Al-Fatiha");
        M.put("De ki: O, Allah'tır, tektir. Allah sameddir (her şey O'na muhtaçtır, O hiçbir şeye muhtaç değildir). O doğurmamış ve doğurulmamıştır. Hiçbir şey O'na denk değildir.",
                "Say: He is Allah, the One. Allah is the Self-Sufficient (all depend on Him, He depends on nothing). He neither begets nor is born. And there is none comparable to Him.");
        M.put("Kevser Sûresi (zamm-ı sûre)",
                "Surah Al-Kawthar (additional surah)");
        M.put("Şüphesiz biz sana Kevser'i verdik. Öyleyse Rabbin için namaz kıl ve kurban kes. Asıl soyu kesik olan, sana buğzedendir.",
                "Indeed, We have granted you Al-Kawthar. So pray to your Lord and sacrifice. Indeed, it is your enemy who is cut off.");
        M.put("Ettehiyyâtü",
                "Tahiyyat");
        M.put("Oturuşlarda (ilk ve son oturuş)",
                "In the sittings (first and final sitting)");
        M.put("Dil ile, beden ve mal ile yapılan bütün ibadetler Allah'a mahsustur. Ey Peygamber! Allah'ın selamı, rahmeti ve bereketi senin üzerine olsun. Selam bizim üzerimize ve Allah'ın salih kulları üzerine olsun. Şahitlik ederim ki Allah'tan başka ilah yoktur ve yine şahitlik ederim ki Muhammed O'nun kulu ve elçisidir.",
                "All greetings, prayers and good deeds are for Allah. Peace be upon you, O Prophet, and the mercy of Allah and His blessings. Peace be upon us and upon the righteous servants of Allah. I bear witness that there is no god but Allah, and I bear witness that Muhammad is His servant and messenger.");
        M.put("Allâhümme salli / Allâhümme bârik (Salavatlar)",
                "Allahumma salli / Allahumma barik (Salawat)");
        M.put("Son oturuşta, Ettehiyyâtü'nden sonra",
                "In the final sitting, after the Tahiyyat");
        M.put("Allahım! İbrahim'e ve İbrahim'in âline rahmet ettiğin gibi Muhammed'e ve Muhammed'in âline de rahmet et. Şüphesiz sen övülmeye layıksın, şanı yücesin. Allahım! İbrahim'e ve âline bereket verdiğin gibi Muhammed'e ve âline de bereket ver. Şüphesiz sen övülmeye layıksın, şanı yücesin.",
                "O Allah! Send mercy upon Muhammad and the family of Muhammad as You sent mercy upon Ibrahim and the family of Ibrahim. Indeed, You are Praiseworthy and Glorious. O Allah! Bless Muhammad and the family of Muhammad as You blessed Ibrahim and the family of Ibrahim. Indeed, You are Praiseworthy and Glorious.");
        M.put("Rabbenâ duaları",
                "Rabbana supplications");
        M.put("Son oturuşta, salavatlardan sonra; ardından selam verilir",
                "In the final sitting, after the salawat; then salaam is given");
        M.put("Rabbimiz! Bize dünyada da iyilik ver, ahirette de iyilik ver ve bizi ateş azabından koru.\nRabbimiz! Hesabın görüleceği gün beni, annemi babamı ve bütün müminleri bağışla.",
                "Our Lord! Give us good in this world and good in the Hereafter, and protect us from the punishment of the Fire.\nOur Lord! Forgive me, my parents and all the believers on the Day when the reckoning will take place.");
        M.put("Kunut duası 1",
                "Qunut supplication 1");
        M.put("Vitir namazının 3. rekâtında, rükûdan önce",
                "In the 3rd rakat of Witr, before the bowing");
        M.put("Allahım! Senden yardım dileriz, bağışlanma isteriz, doğru yolu göstermeni dileriz. Sana inanır, sana tövbe eder, sana güveniriz. Bütün hayırlarla seni överiz. Sana şükreder, nankörlük etmeyiz. Sana isyan edenlerden uzaklaşır ve onları terk ederiz.",
                "O Allah! We ask You for help, we seek Your forgiveness and ask You for guidance. We believe in You, repent to You and rely on You. We praise You with all good. We thank You and are not ungrateful to You. We distance ourselves from those who disobey You and leave them.");
        M.put("Kunut duası 2",
                "Qunut supplication 2");
        M.put("Vitir namazının 3. rekâtında, birinci kunut duasından sonra",
                "In the 3rd rakat of Witr, after the first Qunut supplication");
        M.put("Allahım! Yalnız sana kulluk ederiz, senin için namaz kılar ve secde ederiz. Sana koşar, sana yöneliriz. Rahmetini umar, azabından korkarız. Şüphesiz azabın kâfirlere ulaşacaktır.",
                "O Allah! We worship You alone; we pray and prostrate for You. We hasten to You and turn to You. We hope for Your mercy and fear Your punishment. Indeed, Your punishment will reach the disbelievers.");
        M.put("Namaz sonrası tesbihat",
                "Tasbihat after the prayer");
        M.put("Farz namazlardan sonra, selamın ardından",
                "After the fard prayers, following the salaam");
        M.put("Allah'ı eksikliklerden uzak tutarım (33). Hamd Allah'adır (33). Allah en büyüktür (33). Allah'tan başka ilah yoktur; O tektir, ortağı yoktur. Mülk O'nundur, hamd O'nadır ve O her şeye kadirdir. (Ardından Ayetel Kürsî okunur.)",
                "I declare Allah free of imperfection (33). Praise be to Allah (33). Allah is the Greatest (33). There is no god but Allah; He is One and has no partner. His is the dominion, His is the praise, and He is capable of all things. (Then Ayat al-Kursi is recited.)");
        M.put("Ayetel Kürsî",
                "Ayat al-Kursi");
        M.put("Farz namazlardan sonra, tesbihatla birlikte",
                "After the fard prayers, together with the tasbihat");
        M.put("Allah, kendisinden başka ilah olmayandır; diridir, her şeyi ayakta tutandır. O'nu ne uyuklama tutar ne uyku. Göklerde ve yerde ne varsa O'nundur. İzni olmadan O'nun katında kim şefaat edebilir? Onların önlerindekini ve arkalarındakini bilir. O'nun ilminden, dilediği kadarından başka hiçbir şeyi kavrayamazlar. O'nun kürsüsü gökleri ve yeri kaplamıştır; onları korumak O'na ağır gelmez. O çok yücedir, çok büyüktür.",
                "Allah — there is no god but Him, the Ever-Living, the Sustainer of all. Neither drowsiness nor sleep overtakes Him. To Him belongs whatever is in the heavens and the earth. Who can intercede with Him except by His permission? He knows what is before them and what is behind them. They encompass nothing of His knowledge except what He wills. His Throne extends over the heavens and the earth, and preserving them does not tire Him. He is the Most High, the Most Great.");
        M.put("Fîl Sûresi (zamm-ı sûre)",
                "Surah Al-Fil (additional surah)");
        M.put("Rabbinin fil sahiplerine ne yaptığını görmedin mi? Onların hile ve tuzaklarını boşa çıkarmadı mı? Üzerlerine sürü sürü kuşlar gönderdi. Bu kuşlar onlara pişmiş çamurdan taşlar atıyordu. Böylece onları yenilmiş ekin yaprağı gibi yaptı.",
                "Have you not seen what your Lord did to the people of the elephant? Did He not make their plot go astray? He sent against them flocks of birds, which struck them with stones of baked clay. And He made them like eaten straw.");
        M.put("Felak Sûresi (zamm-ı sûre)",
                "Surah Al-Falaq (additional surah)");
        M.put("De ki: Yarattığı şeylerin şerrinden, karanlığı çöktüğü zaman gecenin şerrinden, düğümlere üfleyenlerin şerrinden ve haset ettiği zaman hasetçinin şerrinden sabahın Rabbine sığınırım.",
                "Say: I seek refuge in the Lord of daybreak from the evil of what He created, from the evil of the darkness when it settles, from the evil of those who blow on knots, and from the evil of the envier when he envies.");
        M.put("Nâs Sûresi (zamm-ı sûre)",
                "Surah An-Nas (additional surah)");
        M.put("De ki: İnsanların Rabbine, insanların Melik'ine, insanların İlahı'na sığınırım; insanların kalplerine vesvese veren sinsi vesvesecinin şerrinden; cinlerden de insanlardan da.",
                "Say: I seek refuge in the Lord of mankind, the King of mankind, the God of mankind; from the evil of the retreating whisperer who whispers in the hearts of mankind, among jinn and among men.");
        M.put("Ezan duası",
                "Prayer after the adhan");
        M.put("Ezan bittikten sonra",
                "After the adhan ends");
        M.put("Ey bu eksiksiz davetin ve kılınacak namazın Rabbi olan Allahım! Muhammed'e vesîle ve fazîleti ver, onu vaat ettiğin makâm-ı mahmûd'a ulaştır.",
                "O Allah, Lord of this perfect call and of the prayer to be performed! Grant Muhammad the wasila and the virtue, and raise him to the praised station (maqam mahmud) that You have promised him.");
    }
    private GuideEn() {}
}
