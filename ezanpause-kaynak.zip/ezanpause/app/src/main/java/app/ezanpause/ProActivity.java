package app.ezanpause;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** EzanPause Pro: Pro'ya hazır olmak için yapılması gerekenler (gerçek kurulum durumuna göre işaretlenir). */
public class ProActivity extends BaseActivity {
    private LinearLayout listBox;
    private TextView tvCount;
    private Ui.Bar bar;
    private Ui.Btn btnActivate;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 1500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = screen();
        topBar(root, "EzanPause Pro");

        LinearLayout hero = Ui.column(this);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor("#FEF3C7"), Color.WHITE});
        bg.setCornerRadius(Ui.dp(this, 24));
        bg.setStroke(Ui.dp(this, 1), Color.parseColor("#FCD34D"));
        hero.setBackground(bg);
        hero.setPadding(Ui.dp(this, 18), Ui.dp(this, 16), Ui.dp(this, 18), Ui.dp(this, 18));

        LinearLayout head = Ui.row(this);
        FrameLayout star = Ui.circleIcon(this, "star", Ui.AMBER_LINE, Color.WHITE, 0, 48, 28);
        star.setClickable(false);
        head.addView(star, Ui.lp(this, Ui.dp(this, 48), Ui.dp(this, 48), 0, 0, 12, 0));
        LinearLayout t = Ui.column(this);
        t.addView(Ui.text(this, "Pro için yapılması gerekenler", 17, Ui.TEXT, true));
        tvCount = Ui.text(this, "", 12, Ui.AMBER, true);
        t.addView(tvCount);
        head.addView(t, Ui.weightLp(this, 1f, 0, 0, 0, 0));
        hero.addView(head);

        bar = new Ui.Bar(this, Color.parseColor("#FDE68A"), Ui.AMBER_LINE);
        hero.addView(bar, Ui.lp(this, android.view.ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 8), 0, 14, 0, 0));
        root.addView(hero, Ui.matchLp(this, 0, 8, 0, 0));

        LinearLayout card = Ui.card(this);
        listBox = Ui.column(this);
        card.addView(listBox);
        root.addView(card, Ui.matchLp(this, 0, 14, 0, 0));

        btnActivate = Ui.button(this, "star", "Pro'yu etkinleştir", Ui.GREEN, Color.WHITE, 0);
        btnActivate.setOnClickListener(v -> Toast.makeText(this,
                "Pro satın alma, uygulama Google Play'de yayınlanınca açılacak. Hazırlıkların tamam!", Toast.LENGTH_LONG).show());
        root.addView(btnActivate, Ui.matchLp(this, 0, 14, 0, 0));

        TextView note = Ui.text(this, "Bu liste kurulumun gerçek durumuna bakar: izin verdiğinizde ve ayarları "
                + "yaptığınızda maddeler kendiliğinden işaretlenir. Satın alma henüz bağlı değildir.", 11, Ui.MUTED, false);
        note.setLineSpacing(0, 1.15f);
        root.addView(note, Ui.matchLp(this, 4, 12, 4, 0));
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    private void refresh() {
        List<ProItems.Item> items = ProItems.items(this);
        int done = ProItems.doneCount(items);
        tvCount.setText(done + " / " + items.size() + " tamamlandı");
        bar.setFraction(done / (float) items.size());

        listBox.removeAllViews();
        for (final ProItems.Item it : items) {
            LinearLayout row = Ui.row(this);
            row.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
            FrameLayout mark = it.done
                    ? Ui.circleIcon(this, "check", Color.WHITE, Ui.GREEN_MID, 0, 28, 16)
                    : Ui.circleIcon(this, "circle", Color.parseColor("#94A3B8"), Color.TRANSPARENT, 0, 28, 24);
            mark.setClickable(false);
            row.addView(mark, Ui.lp(this, Ui.dp(this, 28), Ui.dp(this, 28), 0, 0, 12, 0));

            LinearLayout col = Ui.column(this);
            col.addView(Ui.text(this, it.title, 14, it.done ? Ui.MUTED : Ui.TEXT, true));
            col.addView(Ui.text(this, it.hint, 11, Ui.MUTED, false));
            row.addView(col, Ui.weightLp(this, 1f, 0, 0, 8, 0));

            if (!it.done) {
                Ui.Btn go = Ui.button(this, null, "Yap", Ui.AMBER_BG, Ui.AMBER, 0);
                go.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 16), Ui.dp(this, 6));
                go.setMinimumHeight(Ui.dp(this, 36));
                go.setOnClickListener(v -> runProAction(it.action, this::refresh));
                row.addView(go);
            }
            listBox.addView(row);
            View line = new View(this);
            line.setBackgroundColor(Ui.LINE);
            listBox.addView(line, Ui.lp(this, android.view.ViewGroup.LayoutParams.MATCH_PARENT, 1, 0, 0, 0, 0));
        }
        boolean all = done == items.size();
        btnActivate.setAlpha(all ? 1f : 0.45f);
        btnActivate.label.setText(all ? "Pro'yu etkinleştir" : "Önce listeyi tamamlayın");
        btnActivate.setEnabled(all);
    }
}
