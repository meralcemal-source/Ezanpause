package app.ezanpause;

import android.graphics.Color;
import java.util.ArrayList;
import android.content.Intent;
import android.app.AlertDialog;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** EzanPause Pro: Pro'ya hazır olmak için yapılması gerekenler (gerçek kurulum durumuna göre işaretlenir). */
public class ProActivity extends BaseActivity {
    private LinearLayout listBox;
    private TextView tvCount;
    private Ui.Bar bar;
    private Ui.Btn btnActivate;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 1500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = screen();
        topBar(root, "EzanPause Pro");
        buildAccount(root);

        LinearLayout hero = Ui.column(this);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor("#FEF3C7"), Color.WHITE});
        bg.setCornerRadius(Ui.dp(this, 24));
        bg.setStroke(Ui.dp(this, 1), Color.parseColor("#FCD34D"));
        hero.setBackground(bg);
        hero.setPadding(Ui.dp(this, 18), Ui.dp(this, 16), Ui.dp(this, 18), Ui.dp(this, 18));

        LinearLayout head = Ui.row(this);
        FrameLayout star = Ui.circleIcon(this, "star", Ui.AMBER_LINE, Color.WHITE, 0, 48, 28);
        star.setClickable(false);
        head.addView(star, Ui.lp(this, Ui.dp(this, 48), Ui.dp(this, 48), 0, 0, 12, 0));
        LinearLayout t = Ui.column(this);
        t.addView(Ui.text(this, "Pro için yapılması gerekenler", 17, Ui.TEXT, true));
        tvCount = Ui.text(this, "", 12, Ui.AMBER, true);
        t.addView(tvCount);
        head.addView(t, Ui.weightLp(this, 1f, 0, 0, 0, 0));
        hero.addView(head);

        bar = new Ui.Bar(this, Color.parseColor("#FDE68A"), Ui.AMBER_LINE);
        hero.addView(bar, Ui.lp(this, android.view.ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 8), 0, 14, 0, 0));
        root.addView(hero, Ui.matchLp(this, 0, 8, 0, 0));

        LinearLayout card = Ui.card(this);
        listBox = Ui.column(this);
        card.addView(listBox);
        root.addView(card, Ui.matchLp(this, 0, 14, 0, 0));

        btnActivate = Ui.button(this, "star", "Pro'yu etkinleştir", Ui.GREEN, Color.WHITE, 0);
        btnActivate.setVisibility(View.GONE);
        root.addView(btnActivate, Ui.matchLp(this, 0, 14, 0, 0));

        TextView note = Ui.text(this, "Bu liste kurulumun gerçek durumuna bakar: izin verdiğinizde ve ayarları "
                + "yaptığınızda maddeler kendiliğinden işaretlenir.", 11, Ui.MUTED, false);
        note.setLineSpacing(0, 1.15f);
        root.addView(note, Ui.matchLp(this, 4, 12, 4, 0));
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    private void refresh() {
        List<ProItems.Item> items = ProItems.items(this);
        int done = ProItems.doneCount(items);
        tvCount.setText(I18n.t(done + " / " + items.size() + " tamamlandı"));
        bar.setFraction(done / (float) items.size());

        listBox.removeAllViews();
        for (final ProItems.Item it : items) {
            LinearLayout row = Ui.row(this);
            row.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
            FrameLayout mark = it.done
                    ? Ui.circleIcon(this, "check", Color.WHITE, Ui.GREEN_MID, 0, 28, 16)
                    : Ui.circleIcon(this, "circle", Color.parseColor("#94A3B8"), Color.TRANSPARENT, 0, 28, 24);
            mark.setClickable(false);
            row.addView(mark, Ui.lp(this, Ui.dp(this, 28), Ui.dp(this, 28), 0, 0, 12, 0));

            LinearLayout col = Ui.column(this);
            col.addView(Ui.text(this, it.title, 14, it.done ? Ui.MUTED : Ui.TEXT, true));
            col.addView(Ui.text(this, it.hint, 11, Ui.MUTED, false));
            row.addView(col, Ui.weightLp(this, 1f, 0, 0, 8, 0));

            if (!it.done) {
                Ui.Btn go = Ui.button(this, null, "Yap", Ui.AMBER_BG, Ui.AMBER, 0);
                go.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 16), Ui.dp(this, 6));
                go.setMinimumHeight(Ui.dp(this, 36));
                go.setOnClickListener(v -> runProAction(it.action, this::refresh));
                row.addView(go);
            }
            listBox.addView(row);
            View line = new View(this);
            line.setBackgroundColor(Ui.LINE);
            listBox.addView(line, Ui.lp(this, android.view.ViewGroup.LayoutParams.MATCH_PARENT, 1, 0, 0, 0, 0));
        }
        boolean all = done == items.size();
        btnActivate.setAlpha(all ? 1f : 0.45f);
        btnActivate.label.setText(I18n.t(all ? "Pro'yu etkinleştir" : "Önce listeyi tamamlayın"));
        btnActivate.setEnabled(all);
    }

    private TextView tvPlan;
    private TextView tvDevices;

    private void buildAccount(LinearLayout root) {
        if (!Account.signedIn(this)) {
            LinearLayout c0 = Ui.card(this);
            c0.addView(Ui.text(this, "Hesabım", 16, Ui.TEXT, true));
            c0.addView(Ui.text(this, "Ücretsiz plan hesap gerektirmez. Pro'ya geçmek ve otomatik sessizi kullanmak için giriş yapın veya hesap oluşturun.",
                    12, Ui.MUTED, false), Ui.matchLp(this, 0, 6, 0, 0));
            Ui.Btn bIn = Ui.button(this, "check", "Giriş yap / Kayıt ol", Ui.GREEN, Color.WHITE, 0);
            bIn.setOnClickListener(v -> startActivity(new Intent(this, LoginActivity.class)));
            c0.addView(bIn, Ui.matchLp(this, 0, 12, 0, 0));
            root.addView(c0, Ui.matchLp(this, 0, 8, 0, 0));
            addPrices(root);
            return;
        }
        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, "Hesabım", 16, Ui.TEXT, true));
        card.addView(Ui.text(this, Account.email(this), 13, Ui.MUTED, false), Ui.matchLp(this, 0, 4, 0, 0));
        tvPlan = Ui.text(this, "Plan: " + Account.planText(this), 14, Ui.GREEN, true);
        card.addView(tvPlan, Ui.matchLp(this, 0, 8, 0, 0));
        tvDevices = Ui.text(this, "Cihaz sınırı: " + Account.deviceLimit(this), 12, Ui.MUTED, false);
        card.addView(tvDevices, Ui.matchLp(this, 0, 2, 0, 0));

        Ui.Btn bDev = Ui.button(this, null, "Cihazlarım", Ui.CARD, Ui.TEXT, Ui.LINE);
        bDev.setOnClickListener(v -> showDevices());
        card.addView(bDev, Ui.matchLp(this, 0, 12, 0, 0));
        Ui.Btn bOut = Ui.button(this, null, "Çıkış yap", Ui.CARD, Ui.WARN_RED, Ui.LINE);
        bOut.setOnClickListener(v -> {
            Account.signOutLocal(this);
            startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK));
            finish();
        });
        card.addView(bOut, Ui.matchLp(this, 0, 8, 0, 0));
        Ui.Btn bVer = Ui.button(this, null, "Doğrulama e-postası gönder", Ui.CARD, Ui.TEXT, Ui.LINE);
        bVer.setOnClickListener(v -> Account.sendVerification(this, (ok, m) -> runOnUiThread(() -> Ui.toast(this, m, Toast.LENGTH_LONG))));
        card.addView(bVer, Ui.matchLp(this, 0, 8, 0, 0));
        Ui.Btn bDel = Ui.button(this, null, "Hesabımı sil", Ui.CARD, Ui.WARN_RED, Ui.LINE);
        bDel.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(I18n.t("Hesap silinsin mi?"))
                .setMessage(I18n.t("Hesabınız, planınız ve cihaz kayıtlarınız kalıcı olarak silinir. Bu işlem geri alınamaz."))
                .setPositiveButton(I18n.t("Sil"), (d, w) -> Account.deleteAccount(this, (ok, m) -> runOnUiThread(() -> {
                    if (ok) {
                        Ui.toast(this, "Hesabınız silindi", Toast.LENGTH_LONG);
                        startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK));
                        finish();
                    } else {
                        Ui.toast(this, m, Toast.LENGTH_LONG);
                    }
                })))
                .setNegativeButton(I18n.t("Vazgeç"), null)
                .show());
        card.addView(bDel, Ui.matchLp(this, 0, 8, 0, 0));
        root.addView(card, Ui.matchLp(this, 0, 8, 0, 0));

        addPrices(root);

        Account.refresh(this, (ok, msg) -> runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            if ("KICKED".equals(msg)) {
                finish();
                return;
            }
            tvPlan.setText(I18n.t("Plan: " + Account.planText(this)));
            tvDevices.setText(I18n.t("Cihaz sınırı: " + Account.deviceLimit(this)));
        }));
    }

    private Billing billing;
    private Ui.Btn bMonth, bYear;
    private TextView tvBuyMsg;

    @Override
    protected void onDestroy() {
        if (billing != null) billing.close();
        super.onDestroy();
    }

    private void addPrices(LinearLayout root) {
        LinearLayout price = Ui.card(this);
        price.addView(Ui.text(this, "Pro planları", 16, Ui.TEXT, true));
        price.addView(Ui.text(this, "7 gün ücretsiz · sonra aylık veya yıllık abonelik", 14, Ui.AMBER, true), Ui.matchLp(this, 0, 6, 0, 0));
        price.addView(Ui.text(this, "Pro: ezan vaktinde otomatik sessiz + 5 cihaza kadar kullanım. "
                + "Fiyat, Google Play'de bulunduğunuz ülkenin parasıyla gösterilir. Abonelik istediğiniz zaman Google Play'den iptal edilebilir.", 12, Ui.MUTED, false), Ui.matchLp(this, 0, 6, 0, 0));
        if (!Account.signedIn(this)) {
            price.addView(Ui.text(this, "Satın almak için önce giriş yapın.", 12, Ui.WARN_RED, true), Ui.matchLp(this, 0, 8, 0, 0));
            root.addView(price, Ui.matchLp(this, 0, 12, 0, 0));
            return;
        }
        bMonth = Ui.button(this, "star", "Aylık · yükleniyor…", Ui.GREEN, Color.WHITE, 0);
        bYear = Ui.button(this, "star", "Yıllık · yükleniyor…", Ui.GREEN, Color.WHITE, 0);
        bMonth.setEnabled(false);
        bYear.setEnabled(false);
        bMonth.setAlpha(0.5f);
        bYear.setAlpha(0.5f);
        price.addView(bMonth, Ui.matchLp(this, 0, 12, 0, 0));
        price.addView(bYear, Ui.matchLp(this, 0, 8, 0, 0));
        tvBuyMsg = Ui.text(this, "", 12, Ui.MUTED, false);
        price.addView(tvBuyMsg, Ui.matchLp(this, 0, 8, 0, 0));
        root.addView(price, Ui.matchLp(this, 0, 12, 0, 0));

        billing = new Billing(this, new Billing.Listener() {
            @Override
            public void onPrices(final String monthly, final String yearly) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    setPlanButton(bMonth, "Aylık", monthly, Billing.BASE_MONTHLY);
                    setPlanButton(bYear, "Yıllık", yearly, Billing.BASE_YEARLY);
                    if (monthly == null && yearly == null) tvBuyMsg.setText(I18n.t("Planlar şu an yüklenemedi. Daha sonra tekrar deneyin."));
                });
            }

            @Override
            public void onStatus(final boolean active, final String message) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    tvBuyMsg.setText(I18n.t(message));
                    if (tvPlan != null) tvPlan.setText(I18n.t("Plan: " + Account.planText(ProActivity.this)));
                    if (tvDevices != null) tvDevices.setText(I18n.t("Cihaz sınırı: " + Account.deviceLimit(ProActivity.this)));
                });
            }
        });
        billing.load();
    }

    private void setPlanButton(Ui.Btn b, String name, String text, final String basePlan) {
        if (text == null) {
            b.label.setText(I18n.t(name + " · yok"));
            return;
        }
        b.label.setText(I18n.t(name + " · " + text));
        b.setEnabled(true);
        b.setAlpha(1f);
        b.setOnClickListener(v -> billing.buy(this, basePlan));
    }

    private void showDevices() {
        new Thread(() -> {
            List<Account.Device> list;
            try {
                list = Account.fetchDevices(this);
            } catch (Throwable t) {
                list = new ArrayList<>();
            }
            final List<Account.Device> devs = list;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                final String me = Account.deviceId(this);
                final String[] names = new String[devs.size()];
                for (int i = 0; i < names.length; i++) names[i] = devs.get(i).model + (devs.get(i).id.equals(me) ? " (bu cihaz)" : "");
                new AlertDialog.Builder(this)
                        .setTitle(I18n.t("Cihazlarım — çıkarmak için dokunun"))
                        .setItems(I18n.tAll(names), (d, which) -> {
                            final Account.Device dv = devs.get(which);
                            Account.removeDevice(this, dv.id, false, (ok, m) -> runOnUiThread(() -> {
                                if (dv.id.equals(me)) {
                                    startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK));
                                    finish();
                                } else {
                                    Ui.toast(this, ok ? "Cihaz çıkarıldı" : m, Toast.LENGTH_SHORT);
                                }
                            }));
                        })
                        .setNegativeButton(I18n.t("Kapat"), null)
                        .show();
            });
        }).start();
    }
}
