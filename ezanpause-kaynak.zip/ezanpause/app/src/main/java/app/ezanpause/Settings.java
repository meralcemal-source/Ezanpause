package app.ezanpause;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONException;
import org.json.JSONObject;

/** Kullanıcı ayarları. Süreler SANİYE cinsindendir. */
final class Settings {
    static final int MAX_DURATION_SEC = 7200; // 2 saat
    static final int MAX_OFFSET_SEC = 3600;   // ezandan en fazla 1 saat önce

    private static final String PREFS = "ezanpause_settings";

    boolean enabled = true;
    String city = "İstanbul";
    /** Ezan vaktinden sonra sessizliğin süreceği süre (saniye). */
    int durationSec = 240;
    /** Ezandan kaç saniye ÖNCE sessizlik başlasın. */
    int offsetSec = 0;
    boolean restore = true;
    boolean resume = true;
    boolean imsak = true;
    boolean ogle = true;
    boolean ikindi = true;
    boolean aksam = true;
    boolean yatsi = true;
    /** Perşembe akşamı selâsı (gelenek; yatsıdan önce). */
    boolean sela = false;
    int selaMin = 20;
    /** Cuma selâsı: Cuma günü öğle (Cuma) ezanından kaç dk önce. */
    boolean cumaSela = true;
    int cumaSelaMin = 45;

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static Settings load(Context c) {
        SharedPreferences p = prefs(c);
        Settings s = new Settings();
        s.enabled = p.getBoolean("enabled", s.enabled);
        s.city = p.getString("city", s.city);
        s.durationSec = clamp(p.getInt("durationSec", s.durationSec), 1, MAX_DURATION_SEC);
        s.offsetSec = clamp(p.getInt("offsetSec", s.offsetSec), 0, MAX_OFFSET_SEC);
        s.restore = p.getBoolean("restore", s.restore);
        s.resume = p.getBoolean("resume", s.resume);
        s.imsak = p.getBoolean("imsak", s.imsak);
        s.ogle = p.getBoolean("ogle", s.ogle);
        s.ikindi = p.getBoolean("ikindi", s.ikindi);
        s.aksam = p.getBoolean("aksam", s.aksam);
        s.yatsi = p.getBoolean("yatsi", s.yatsi);
        s.sela = p.getBoolean("sela", s.sela);
        s.selaMin = Math.max(5, Math.min(120, p.getInt("selaMin", s.selaMin)));
        s.cumaSela = p.getBoolean("cumaSela", s.cumaSela);
        s.cumaSelaMin = Math.max(5, Math.min(120, p.getInt("cumaSelaMin", s.cumaSelaMin)));
        return s;
    }

    void save(Context c) {
        durationSec = clamp(durationSec, 1, MAX_DURATION_SEC);
        offsetSec = clamp(offsetSec, 0, MAX_OFFSET_SEC);
        prefs(c).edit()
                .putBoolean("enabled", enabled)
                .putString("city", city)
                .putInt("durationSec", durationSec)
                .putInt("offsetSec", offsetSec)
                .putBoolean("restore", restore)
                .putBoolean("resume", resume)
                .putBoolean("imsak", imsak)
                .putBoolean("ogle", ogle)
                .putBoolean("ikindi", ikindi)
                .putBoolean("aksam", aksam)
                .putBoolean("yatsi", yatsi)
                .putBoolean("sela", sela)
                .putInt("selaMin", selaMin)
                .putBoolean("cumaSela", cumaSela)
                .putInt("cumaSelaMin", cumaSelaMin)
                .apply();
    }

    /** Profil kaydı için ayarları JSON olarak verir. */
    JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("enabled", enabled);
            o.put("city", city);
            o.put("durationSec", durationSec);
            o.put("offsetSec", offsetSec);
            o.put("restore", restore);
            o.put("resume", resume);
            o.put("imsak", imsak);
            o.put("ogle", ogle);
            o.put("ikindi", ikindi);
            o.put("aksam", aksam);
            o.put("yatsi", yatsi);
            o.put("sela", sela);
            o.put("selaMin", selaMin);
            o.put("cumaSela", cumaSela);
            o.put("cumaSelaMin", cumaSelaMin);
        } catch (JSONException ignored) {
        }
        return o;
    }

    static Settings fromJson(JSONObject o) {
        Settings s = new Settings();
        s.enabled = o.optBoolean("enabled", s.enabled);
        s.city = o.optString("city", s.city);
        s.durationSec = clamp(o.optInt("durationSec", s.durationSec), 1, MAX_DURATION_SEC);
        s.offsetSec = clamp(o.optInt("offsetSec", s.offsetSec), 0, MAX_OFFSET_SEC);
        s.restore = o.optBoolean("restore", s.restore);
        s.resume = o.optBoolean("resume", s.resume);
        s.imsak = o.optBoolean("imsak", s.imsak);
        s.ogle = o.optBoolean("ogle", s.ogle);
        s.ikindi = o.optBoolean("ikindi", s.ikindi);
        s.aksam = o.optBoolean("aksam", s.aksam);
        s.yatsi = o.optBoolean("yatsi", s.yatsi);
        s.sela = o.optBoolean("sela", s.sela);
        s.selaMin = Math.max(5, Math.min(120, o.optInt("selaMin", s.selaMin)));
        s.cumaSela = o.optBoolean("cumaSela", s.cumaSela);
        s.cumaSelaMin = Math.max(5, Math.min(120, o.optInt("cumaSelaMin", s.cumaSelaMin)));
        return s;
    }

    int prayerCount() {
        int n = 0;
        if (imsak) n++;
        if (ogle) n++;
        if (ikindi) n++;
        if (aksam) n++;
        if (yatsi) n++;
        return n;
    }

    static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
