package app.ezanpause;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Ortak ekran iskeleti, izin ve GPS işlemleri. */
public abstract class BaseActivity extends Activity {
    static final int REQ_NOTIFICATIONS = 101;
    static final int REQ_LOCATION = 102;

    interface GpsCallback {
        void onStatus(String text, boolean found);
    }

    protected final Handler handler = new Handler(Looper.getMainLooper());
    private GpsCallback pendingGps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        lightBars();
    }

    @SuppressWarnings("deprecation")
    private void lightBars() {
        View d = getWindow().getDecorView();
        int flags = d.getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        d.setSystemUiVisibility(flags);
    }

    /** Kaydırılabilir, kenar boşluklarını sistem çubuklarına göre ayarlayan ana sütunu döndürür. */
    @SuppressWarnings("deprecation")
    protected LinearLayout screen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Ui.BG);
        scroll.setFillViewport(true);
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets.consumeSystemWindowInsets();
        });
        LinearLayout root = Ui.column(this);
        root.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 32));
        scroll.addView(root, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);
        return root;
    }

    /** Alt ekranlar için geri düğmeli başlık satırı. */
    protected void topBar(LinearLayout root, String title) {
        LinearLayout bar = Ui.row(this);
        FrameLayout back = Ui.circleIcon(this, "chevron_left", Ui.TEXT, Ui.CARD, Ui.LINE, 44, 22);
        back.setOnClickListener(v -> finish());
        back.setContentDescription("Geri");
        bar.addView(back, Ui.lp(this, Ui.dp(this, 44), Ui.dp(this, 44), 0, 0, 12, 0));
        bar.addView(Ui.text(this, title, 22, Ui.TEXT, true));
        root.addView(bar, Ui.matchLp(this, 0, 4, 0, 6));
    }

    // ------------------------------------------------------------------ izinler

    protected void requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
        if (Build.VERSION.SDK_INT < 33 || !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
            handler.postDelayed(() -> {
                if (!getSystemService(NotificationManager.class).areNotificationsEnabled()) {
                    startSettings(new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, getPackageName()));
                }
            }, 800);
        }
    }

    protected void openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            startSettings(new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    protected void openBatterySettings() {
        startSettings(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
    }

    protected void startSettings(Intent i) {
        try {
            startActivity(i);
        } catch (RuntimeException e) {
            try {
                startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
            } catch (RuntimeException ignored) {
            }
        }
    }

    /** Eksik ilk izni ister. Hepsi tamamsa true döner. */
    protected boolean requestNextMissingPermission() {
        if (!Scheduler.canScheduleExact(this)) {
            openExactAlarmSettings();
            return false;
        }
        if (!getSystemService(NotificationManager.class).areNotificationsEnabled()) {
            requestNotifications();
            return false;
        }
        android.os.PowerManager pm = (android.os.PowerManager) getSystemService(Context.POWER_SERVICE);
        if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
            openBatterySettings();
            return false;
        }
        return true;
    }

    // ------------------------------------------------------------------ deneme ve elle sessizlik

    protected void startTest() {
        Settings s = Settings.load(this);
        int dur = Settings.clamp(s.durationSec, 5, 120);
        long start = System.currentTimeMillis() + 3000;
        Scheduler.addManualWindow(this, start, start + dur * 1000L, "Deneme");
        Settings.prefs(this).edit().putBoolean("test_done", true).apply();
        Toast.makeText(this, "3 sn sonra " + dur + " sn sessizlik", Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------ şehir ve GPS

    protected void showCityDialog(final Runnable after, final GpsCallback gps) {
        final String[] names = PrayerTimes.cityNames();
        new AlertDialog.Builder(this)
                .setTitle("Şehir seç")
                .setItems(names, (d, which) -> {
                    Settings s = Settings.load(this);
                    s.city = names[which];
                    s.save(this);
                    Settings.prefs(this).edit().putBoolean("city_chosen", true).apply();
                    Profiles.syncActive(this);
                    Scheduler.tick(this);
                    if (after != null) after.run();
                })
                .setNeutralButton("Konumdan bul", (d, w) -> findCityByGps(gps, after))
                .setNegativeButton("Vazgeç", null)
                .show();
    }

    protected void findCityByGps(final GpsCallback cb, final Runnable after) {
        boolean granted = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (!granted) {
            pendingGps = cb;
            pendingAfter = after;
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            return;
        }
        if (cb != null) cb.onStatus("Konum aranıyor…", false);
        LocationFinder.find(this, loc -> {
            if (isFinishing() || isDestroyed()) return;
            if (loc == null) {
                if (cb != null) cb.onStatus("Konum alınamadı. Konum (GPS) servisinin açık olduğundan emin olun; "
                        + "olmazsa şehri listeden seçin.", false);
                return;
            }
            PrayerTimes.City c = PrayerTimes.nearest(loc.getLatitude(), loc.getLongitude());
            long km = Math.round(PrayerTimes.distanceKm(loc.getLatitude(), loc.getLongitude(), c.lat, c.lng));
            Settings s = Settings.load(this);
            s.city = c.name;
            s.save(this);
            Settings.prefs(this).edit().putBoolean("city_chosen", true).apply();
            Profiles.syncActive(this);
            Scheduler.tick(this);
            if (cb != null) {
                cb.onStatus("Bulunan şehir: " + c.name + " (yaklaşık " + km + " km)"
                        + (km > 120 ? "\nUyarı: kayıtlı en yakın şehir uzakta; vakitler birkaç dakika farklı olabilir." : ""), true);
            }
            if (after != null) after.run();
        });
    }

    private Runnable pendingAfter;

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean ok = false;
            for (int r : grantResults) if (r == PackageManager.PERMISSION_GRANTED) ok = true;
            GpsCallback cb = pendingGps;
            Runnable after = pendingAfter;
            pendingGps = null;
            pendingAfter = null;
            if (ok) findCityByGps(cb, after);
            else if (cb != null) cb.onStatus("Konum izni verilmedi. Şehri listeden seçebilirsiniz.", false);
        }
    }

    // ------------------------------------------------------------------ Pro listesi eylemleri

    /** "Pro için yapılması gerekenler" satırına dokunulunca ilgili işlemi yapar. */
    protected void runProAction(String action, final Runnable after) {
        switch (action) {
            case "exact":
                openExactAlarmSettings();
                break;
            case "notif":
                requestNotifications();
                break;
            case "battery":
                openBatterySettings();
                break;
            case "test":
                startTest();
                break;
            case "city":
                showCityDialog(after, (text, found) -> Toast.makeText(this, text, Toast.LENGTH_LONG).show());
                break;
            default: // profile, prayers
                if (this instanceof SettingsActivity) {
                    Toast.makeText(this, "Bu bölüm aşağıda", Toast.LENGTH_SHORT).show();
                } else {
                    startActivity(new Intent(this, SettingsActivity.class));
                }
        }
    }

    // ------------------------------------------------------------------ hata raporu

    /** Uygulama geçen sefer çöktüyse hata metnini gösterir (kopyalanıp geliştiriciye iletilebilir). */
    protected void showCrashIfAny() {
        final String crash = App.lastCrash(this);
        if (crash == null) return;
        TextView tv = new TextView(this);
        tv.setText(crash);
        tv.setTextSize(10);
        tv.setTextIsSelectable(true);
        tv.setTextColor(Ui.TEXT);
        tv.setPadding(Ui.dp(this, 16), Ui.dp(this, 8), Ui.dp(this, 16), Ui.dp(this, 8));
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle("Uygulama geçen sefer hata verdi")
                .setView(sv)
                .setPositiveButton("Kopyala", (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("EzanPause hata", crash));
                    Toast.makeText(this, "Kopyalandı. Bana yapıştırın.", Toast.LENGTH_LONG).show();
                    App.clearCrash(this);
                })
                .setNegativeButton("Kapat", (d, w) -> App.clearCrash(this))
                .show();
    }
}
